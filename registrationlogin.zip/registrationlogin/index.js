const express =require('express')
const app=express()
const port=8057
var md5 = require('md5');
var bodyParser=require("body-parser"); 
app.set('view engine','ejs');
const jwt = require("jsonwebtoken");
var mysql = require('mysql');
const { Result } = require('express-validator');
app.use(bodyParser.urlencoded({extended:true})); 

app.use(express.static('public'))

var db = mysql.createConnection({
    host     : 'localhost',
    user     : 'root',
    password : 'root',
    database : 'masterdb',
    dateStrings:true
});

app.get('/reg',(req,res)=>{
    res.render('reg')
})

function randomString(length, chars) {
    var result = '';
    for (var i = length; i > 0; --i) result += chars[Math.floor(Math.random() * chars.length)];
    return result;
}




app.post('/reg',(req,res)=>{

    var hlink = randomString(32, '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ');
    email=req.body.email
    console.log(email,"*****************************************************************")
    db.query(`select count(*) as count from registration where email='${email}'`,(err,result)=>{
        if(err) throw err;
        const count =result[0].count;
        var emailExists= count===1;
        console.log(count)
        console.log(emailExists)
        if(emailExists==true){
            console.log("jay");
            res.render('reg',{'msg':emailExists})
        }
        else{
            console.log("dhar")
            db.query(`INSERT INTO registration (firstname, lastname, phone, gender,email,city,birthdate,hreflink) VALUES('${req.body.fname}','${req.body.lname}','${req.body.phone}','${req.body.radio}','${req.body.email}','${req.body.city}','${req.body.DateOfBirth}','${hlink}')`,(err,result)=>{
                if (err) throw err;
                res.render('active',{'link':hlink})
            })
        }
    })
    
})


// app.get('/createpass/:link',(req,res)=>{

//     var link=req.params.link
//     db.query(`select createdat from registration where hreflink='${link}'`,(err,result)=>{
//         if(err)throw err;
//         console.log(result,"time")
//         var currenttime=new Date().toTimeString();
//         var time=new Date(new Date(result[0].createdat).getTime()+ 5 * 60000).toTimeString();
//         if(currenttime<time){
//             res.render('createpass')
//         }
//         else{
//             db.query(`update registration set userstatus='deactive' where hreflink='${link}'`)
//             res.send('link is expire')
//         }

//     })
    
// })
app.get('/createpass/:link',(req,res)=>{

    var link=req.params.link
    db.query(`select createdat from registration where hreflink='${link}'`,(err,result)=>{
        if(err)throw err;
        console.log(result,"time")
        var currenttime=new Date().toTimeString();
        var time=new Date(new Date(result[0].createdat).getTime()+ 5 * 60000).toTimeString();
        if(currenttime<time){
            res.render('createpass')
        }
        else{
            db.query(`update registration set userstatus='deactive' where hreflink='${link}'`)
            res.send('link is expire')
        }

    })
    
})

app.post('/createpass/:link',(req,res)=>{
    let link=req.params.link
    var sault = randomString(4, '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ');

    password=req.body.password
    concatp=password+`${sault}`
    newpassword=md5(concatp)

    db.query(`update registration set userstatus='active',password='${newpassword}',sault='${sault}' where hreflink='${link}'`)
    res.send(`user is active and login link is : http://127.0.0.1:8057/login`)
})




app.get('/login',(req,res)=>{
    res.render('login')
})

app.get('/forgot',(req,res)=>{
    res.render('forgot')
})

app.post('/forgot',(req,res)=>{
    email=req.body.email
    db.query(`select hreflink from registration where email='${req.body.email}'`,(err,result)=>{
        if(err) throw err;
        console.log(result,"{}{}{}")
        res.redirect(`/createpass/${result[0].hreflink}`)
    })

    
})

//old login code
// app.get('/login',(req,res)=>{
//     link=req.params.id
//     console.log(link,"MMMMMMMMMMMMMMMMMMMMMMMMMMMMMM")
//     res.render('login',{'link':link})
// })

// app.post('/login',(req,res)=>{
//     db.query(`select sault from registration`,(err,result)=>{
//         result.forEach(element => {
//             if(err)throw err;
//             console.log(element,"[][")
//             db.query(`select count(*) as count from registration where email='${req.body.email}' and password='${md5(req.body.password+element.sault)}'`,(err,data)=>{
//                 if(err) throw err;
//                 console.log(data[0].count)
//                 if(data[0].count==1)
//                 {
//                     res.send('login successful')
//                 }
//             })
//         });
// })
// })
//login with JWT token
app.post('/login',async(req,res,next)=>{
    // let { email, password } = req.body;
         db.query(`select sault,hreflink from registration where email='${req.body.email}'`,(err,result)=>{
      
                    if(err)throw err;
                    console.log(result,"sffsdfsdf{}{}{}{}{}{}{")
                    db.query(`select count(*) as count from registration where email='${req.body.email}' and password='${md5(req.body.password+result[0].sault)}'`,(err,data)=>{
                        if(err) throw err;
                        console.log(data[0].count)
                        if(data[0].count!=1)
                        {
                            
                            return res.status(401).json({ error: 'Authentication failed' });                       
                        }
                        else{
                            
                            let token;
                            try {
                                //Creating jwt token
                                token = jwt.sign(
                                    {
                                        email: req.body.email
                                    },
                                    "secretkeyappearshere",
                                    { expiresIn: "1h" }
                                );
                            } catch (err) {
                                console.log(err);
                                const error =
                                    new Error("Error! Something went wrong.");
                                return next(error);
                            }
                                
                            res
                                .status(200)
                                .json({
                                    success: true,
                                    data: {
                                        email: req.body.email,
                                        token: token,
                                    },
                                });                        
                            }
                    })
                    
            })

    
            
// })  
})


//login code updated
app.post('/login',(req,res)=>{
    db.query(`select sault,hreflink from registration where email='${req.body.email}'`,(err,result)=>{
      
            if(err)throw err;
            console.log(result,"sffsdfsdf{}{}{}{}{}{}{")
            db.query(`select count(*) as count from registration where email='${req.body.email}' and password='${md5(req.body.password+result[0].sault)}'`,(err,data)=>{
                if(err) throw err;
                console.log(data[0].count)
                if(data[0].count==1)
                {
                    res.redirect('/tasklist')
                    // res.send('login successful')
                }
                else{
                    res.send('login unsuccessful')
                }
            })
            
})
})




app.get('/tasklist',(req,res)=>{
    res.render('tasklist')
})
app.get('/task1',(req,res)=>{
    res.render('tasks/task1')
})

app.get('/task2',(req,res)=>{
    res.render('tasks/task2')
})
app.get('/task3',(req,res)=>{
    res.render('tasks/task3')
})
app.get('/task4',(req,res)=>{
    res.render('tasks/task4')
})
app.get('/task5',(req,res)=>{
    res.render('tasks/task5')
})

app.get('/task6',(req,res)=>{

    db.query('select * from studentmaster limit 100',function(error,row,fields){
        if (error) throw error;
        col=[]
        // console.log(fields[0].name,"***************")
        // console.log(row[0],"row")
        // console.log(row,"row")
        for (i=0;i<fields.length;i++){
            col.push(fields[i].name)

        }
        // console.log(col) 
        res.render('tasks/task6',{'col':col,'row':row})

    })
    
})
app.get('/task7/:id',(req,res)=>
{   
    var maxpage;
    maximumrow=200 
    var id=req.params.id;
    startind=(id-1)*maximumrow
    // console.log(startind,maximumrow,"*************************************************")
    db.query('select count(*) as count from studentmaster ',function(error,row,fields){
        // console.log(row,"counter row ")
        if (error) throw error;
        maxpage=row[0].count/maximumrow;
    })
    db.query('select * from studentmaster limit '+ startind + ',' + maximumrow,function(error,row,fields){
        if (error) throw error;
        col=[]
        for (i=0;i<fields.length;i++){
            col.push(fields[i].name)

        }
        res.render('tasks/task7',{'id':id,'col':col,'row':row,'max':maximumrow,'startind':startind,'maxpage':maxpage})
    })
   
})

app.get('/task8/:names/:id',(req,res)=>
{   
    var maxpage;
    maximumrow=200 
    var id=req.params.id;
    var name=req.params.names;
    startind=(id-1)*maximumrow
    // console.log(startind,maximumrow,"*************************************************")
    db.query('select count(*) as count from studentmaster ',function(error,row,fields){
        // console.log(row,"counter row ")
        if (error) throw error;
        maxpage=row[0].count/maximumrow;
    })

    db.query('select * from studentmaster order by '+name+' limit '+ startind + ',' + maximumrow,function(error,row,fields){
        if (error) throw error;
        col=[]
        for (i=0;i<fields.length;i++){
            col.push(fields[i].name)

        }
        res.render('tasks/task8',{'id':id,'col':col,'row':row,'max':maximumrow,'startind':startind,'maxpage':maxpage,'name':name })
    })
    
})

//task 9 start 
app.get('/task9',(req,res)=>{

    var query=req.body.str;

    res.render('tasks/task9',{display:"no",query:query})
})

app.post('/task9',(req,res)=>{
    var query=req.body.str;
    seprate=query.replace(/(?=[$-/:-?{-~!"^_`\[\]])/gi,",");
    var splitstring=seprate.split(',');

    var val;
    var firstname=[];
    var lastname=[];
    var email=[];
    var contactnumber=[];
    var address=[];
    var city=[];


    for (i=0;i<splitstring.length;i++){
        if(splitstring[i].startsWith('_')){
            val=splitstring[i].replace('_', '');
            firstname.push(val);
        }
        if(splitstring[i].startsWith('^')){
            val=splitstring[i].replace('^', '');
            lastname.push(val);
        }
        if(splitstring[i].startsWith('$')){
            val=splitstring[i].replace('$', '');
            email.push(val);
        }
        if(splitstring[i].startsWith('{')){
            val=splitstring[i].replace('{', '');
            contactnumber.push(val);
        }
        if(splitstring[i].startsWith('}')){
            val=splitstring[i].replace('}', '');
            address.push(val);
        }
        if(splitstring[i].startsWith(':')){
            val=splitstring[i].replace(':', '');
            city.push(val);
        }
    }

    let sql=`select * from studentmaster where (`
    if (firstname.length>=1){
        for(i=0;i<firstname.length;i++){
            sql+= `firstname like '%${firstname[i]}%' or `
        }
        sql = sql.slice(0,sql.length - 3)+ ') and (';

        }
        if (firstname.length>=1){
            for(i=0;i<firstname.length;i++){
                sql+= `firstname like '%${firstname[i]}%' or `
            }
            sql = sql.slice(0,sql.length - 3)+ ') and (';
    
            }
            if (lastname.length>=1){
                for(i=0;i<lastname.length;i++){
                    sql+= `lastname like '%${lastname[i]}%' or `
                }
                sql = sql.slice(0,sql.length - 3)+ ') and (';
        
                }
                if (email.length>=1){
                    for(i=0;i<email.length;i++){
                        sql+= `email like '%${email[i]}%' or `
                    }
                    sql = sql.slice(0,sql.length - 3)+ ') and (';
            
                    }
                    if (contactnumber.length>=1){
                        for(i=0;i<contactnumber.length;i++){
                            sql+= `contactnumber like '%${contactnumber[i]}%' or `
                        }
                        sql = sql.slice(0,sql.length - 3)+ ') and (';
                
                        }
                        if (address.length>=1){
                            for(i=0;i<address.length;i++){
                                sql+= `address like '%${address[i]}%' or `
                            }
                            sql = sql.slice(0,sql.length - 3)+ ') and (';
                    
                            }
                            if (city.length>=1){
                                for(i=0;i<city.length;i++){
                                    sql+= `city like '%${city[i]}%' or `
                                }
                                sql = sql.slice(0,sql.length - 3)+ ') and (';
                        
                                }

                            sql=sql.slice(0,sql.length - 6);
                            console.log(sql)
                            db.query(sql,(err,result)=>{
                                res.render('tasks/task9',{data:result,display:"show",query:query});
                            })
    
})

// task 9 end 

// task 10

app.get('/task10/:conname',(req,res)=>{
    conname=req.params.conname;
    db.query(`select s.contype,o.option_id,o.select_id,o.option_value from optionmaster as o inner join selectmaster as s on o.select_id=s.select_id where o.select_id in (select select_id from selectmaster as s where s.select_name like '${conname}');
    `,(err,row)=>{
        if(err) throw err;
        res.render('tasks/task10',{row:row,conname:conname})
    }
    )
})


// task 10 end 


//task 11 start

app.get('/task11/:id',(req,res)=>{

    var id=req.params.id
    maxrow=15;
    startind=(id-1)*maxrow
    var maxpage=Math.ceil(200/maxrow);
    console.log(maxpage,"maxpage is ")

    db.query(`select r.studentid,s.firstname,s.lastname,sum(case when r.examid=1 then r.totalmarkstheory end) as exam1TT,sum(case when r.examid=1 then r.obtainmarkstheory end) as exam1OT,sum(case when r.examid=1 then r.totalmarkspractical end) as exam1TP ,sum(case when r.examid=1 then r.obtainmarkspractical end) as exam1OP,
    sum(case when r.examid=2 then r.totalmarkstheory end) as exam2TT,sum(case when r.examid=2 then r.obtainmarkstheory end) as exam2OT,sum(case when r.examid=2 then r.totalmarkspractical end) as exam2TP ,sum(case when r.examid=2 then r.obtainmarkspractical end) as exam2OP,
    sum(case when r.examid=3 then r.totalmarkstheory end) as exam3TT,sum(case when r.examid=3 then r.obtainmarkstheory end) as exam3OT,sum(case when r.examid=3 then r.totalmarkspractical end) as exam3TP ,sum(case when r.examid=3 then r.obtainmarkspractical end) as exam3OP,((sum(case when r.examid=1 then r.obtainmarkstheory end)+sum(case when r.examid=1 then r.obtainmarkspractical end))+(sum(case when r.examid=2 then r.obtainmarkstheory end)+sum(case when r.examid=2 then r.obtainmarkspractical end))+(sum(case when r.examid=3 then r.obtainmarkstheory end)+sum(case when r.examid=3 then r.obtainmarkspractical end))) as finalmarks
    from resultmaster as r inner join studentmaster as s on r.studentid=s.studentid where subjectid between 1 and 6 group by studentid limit `+ startind + ',' + maxrow,function(error,row,fields){
        if (error) throw error;
        // console.log(row)
        // console.log(fields)
        col=[]  
        for (i=0;i<fields.length;i++)
            col.push(fields[i].name)
        res.render('tasks/task11',{'col':col,'row':row,'id':id,'maxrow':maxrow,'maxpage':maxpage})

    })
})



app.get('/task11/specificresult/:id',(req,res)=>{
    var id= req.params.id
    console.log(id)
    
    db.query(`select s.studentid,s.firstname,s.lastname,sub.subjectname,r.subjectid,r.examid,r.obtainmarkstheory,r.obtainmarkspractical,(r.obtainmarkstheory+r.obtainmarkspractical) as total from studentmaster as s inner join resultmaster as r on s.studentid = r.studentid inner join subjectmaster as sub on sub.subject_id=r.subjectid where r.studentid=`+id,function(error,row,fields){
        col=[]
        marks1=[]
        marks2=[]
        marks3=[]
        for (i=0;i<fields.length;i++)
            col.push(fields[i].name)

        for (i=0;i<row.length;i++){
            if (row[i].examid==1){
                marks1.push(row[i].total)
            }
            if (row[i].examid==2){
                marks2.push(row[i].total)
            }
            if (row[i].examid==3){
                marks3.push(row[i].total)
            }
            
        }
        let sum1 = 0;
        marks1.forEach((el) => sum1 += el);
        percentage1=(sum1*100/300).toFixed(2)+' '+`%`
        console.log(percentage1,'1')
        
        let sum2=0;
        marks2.forEach((el) => sum2 += el);
        percentage2=(sum2*100/300).toFixed(2)+' '+`%`
        console.log(percentage2,"2")

        let sum3=0;
        marks3.forEach((el) => sum3 += el);
        percentage3=(sum3*100/600).toFixed(2)+' '+`%`
        console.log(percentage3,"3")

    res.render('tasks/specificresult',{'col':col,'row':row,'percentage1':percentage1,'percentage2':percentage2,'percentage3':percentage3}) })
})



//task 11 end


//task 12 start 

app.get('/task12',(req,res)=>{
    res.render('tasks/task12');
    
})


app.get('/get/:id',(req,res)=>{
    id=req.params.id
    console.log(id)
    db.query(`SELECT * FROM EmployeeBasicDetails where empid='${id}'`,(err,row,fields)=>{
        if (err) throw err;
        db.query(`SELECT * FROM EducationDetail where empid='${id}'`,(err,rowedu)=>{
            if(err)throw err;
        db.query(`SELECT * FROM WorkExperience where empid='${id}'`,(err,rowwork)=>{
            if(err)throw err;
        
        db.query(`SELECT * FROM LanguageMaster where empid='${id}'`,(err,row2)=>{
            if (err) throw err;
            console.log(row2,"language data =========")

        db.query(`SELECT * FROM TechnologyMaster where empid='${id}'`,(err,row3)=>{
            if (err) throw err;
            console.log(row3,"language data =========")
        db.query(`SELECT * FROM ReferenceContact where empid='${id}'`,(err,rowref)=>{
            if (err) throw err;
        db.query(`SELECT * FROM preferences where empid='${id}'`,(err,rowpre)=>{
            if (err) throw err;
            res.render('tasks/task12',{'row':row,'rowedu':rowedu,'rowwork':rowwork,'row2':row2,'row3':row3,'rowref':rowref,'rowpre':rowpre})    
        }) 
    }) 
    })

    })
    })
    })

        
    })

})
app.post('/get/:id',(req,res)=>{
    id=req.params.id
    console.log(req.body)

    db.query(`update EmployeeBasicDetails set firstname='${req.body.fname}',lastname='${req.body.lname}',designation_eb='${req.body.designationba}',phone='${req.body.phone}',gender='${req.body.radio}',email='${req.body.email}',address1='${req.body.address1}',address2='${req.body.address2}',city='${req.body.city}',state='${req.body.state}',birthdate='${req.body.DateOfBirth}' where empid='${id}'`,(err,result)=>
    {
        if(err) throw err;
    })
  
    for(i=0;i<req.body.nob.length;i++){
        if(req.body.nob[i]!=""){
            newid=req.body.edudetailid
            console.log(newid,"newid")

            db.query(`update EducationDetail set boardname='${req.body.nob[i]}', passingyear='${req.body.passingyear[i]}',percentage='${req.body.percentage[i]}' where edudetailid='${newid[i]}'`,(err,result)=>{
                if (err) throw err;
                console.log(result)
                if(err) throw err;
            })}
        
    }
    for(j=0;j<req.body.companyname.length;j++){
        if(req.body.companyname[j]!=""){
            newworkid=req.body.workid
            console.log(newworkid,"workid   ")
            db.query(`update WorkExperience set compname='${req.body.companyname[j]}',designation='${req.body.designation[j]}',durationfrom='${req.body.from[j]}',durationto='${req.body.to[j]}' where workexpid='${newworkid[j]}'`,(err,result)=>{
                if(err) throw err;
            })
        }
    }
    if(req.body.language != undefined){
        for (i=0;i<req.body.language.length;i++){
            if(req.body.language[i]!=""){
                newlanid=req.body.lanid

                let read=req.body[req.body.language[i]+"_read"];
                let speak=req.body[req.body.language[i]+"_speak"];
                let write=req.body[req.body.language[i]+"_write"];
                console.log(read,"read",speak,"speak","****************************************************************")
                if(read==undefined){
                    read=0;
                }
                if(speak==undefined){
                    speak=0;
                }
                if(write==undefined){
                    write=0;
                }
            

                // req.body.language[i]
                db.query(`update LanguageMaster set lanvalue='${req.body.language[i]}', read_test='${read}', speak='${speak}', write_test='${write}' where lanid='${newlanid[i]}'`,(err)=>{
                    if(err) throw err;
                })
            }
        }
    }

    console.log(req.body.techid[0],req.body.technology[0],"techid***************88")

    if(req.body.technology[0]){
        db.query(`update TechnologyMaster set techvalue='${req.body.technology[0]}',techproficiency='${req.body.phpkn}' where techid='${req.body.techid[0]}'`);
    }
    if(req.body.technology[1]){
        db.query(`update TechnologyMaster set techvalue='${req.body.technology[1]}',techproficiency='${req.body.mysqlkn}' where techid='${req.body.techid[1]}'`);
    }
    if(req.body.technology[2]){
        db.query(`update TechnologyMaster set techvalue='${req.body.technology[2]}',techproficiency='${req.body.laravelkn}' where techid='${req.body.techid[2]}'`);
    }
    if(req.body.technology[3]){
        db.query(`update TechnologyMaster set techvalue='${req.body.technology[3]}',techproficiency='${req.body.oraclekn}' where techid='${req.body.techid[3]}'`);
    }

    for(i=0;i<req.body.referencename.length;i++){

        if(req.body.referencename[i]!=""){
            newrefid=req.body.refid

            db.query(`update ReferenceContact set name='${req.body.referencename[i]}',contactnumber='${req.body.contactnumber[i]}',relation='${req.body.relation[i]}' where refid='${newrefid[i]}'`,(err)=>{
                if(err) throw err;
            })
        }
    }
    db.query(`update preferences set preferencelocation='${req.body.preferdlocation}',noticeperiod='${req.body.noticeperiod}',expectedCtc='${req.body.expectedctc}',currentCtc='${req.body.currentctc}',department='${req.body.department}' where preferenceid='${req.body.preferenceid}'`,(err)=>{
        if(err) throw err;
    })
    
    res.end('updated')

})

app.post('/task12',(req,res)=>{
    console.log("post")
    console.log(req.body,"body is ")

    fname=req.body.fname
    lname=req.body.lname
    dg=req.body.designationba
    phone=req.body.phone
    email=req.body.email
    address1=req.body.address1
    address2=req.body.address2
    city=req.body.city
    state=req.body.states
    birthdate=req.body.DateOfBirth
    gender=req.body.radio





   db.query(`INSERT INTO EmployeeBasicDetails (firstname, lastname, designation_eb, phone, gender,email,address1,address2,city,state,birthdate) VALUES('${fname}','${lname}','${dg}','${phone}','${gender}','${email}','${address1}','${address2}','${city}','${state}','${birthdate}')`,(err,result)=>{
    if (err) throw err;
    lastid=result.insertId

    //insert education section details
    for(i=0;i<req.body.nob.length;i++){
        if(req.body.nob[i]!=""){

            db.query(`INSERT INTO EducationDetail(empid,boardname,passingyear, percentage) VALUES ('${lastid}', '${req.body.nob[i]}', '${req.body.passingyear[i]}','${req.body.percentage[i]}')`,(err,result)=>{
                if (err) throw err;
            })
        }
    }
    // work experience
    for(i=0;i<req.body.companyname.length;i++){
        if(req.body.companyname[i]!=""){

            db.query(`INSERT INTO WorkExperience(empid,compname,designation,durationfrom,durationto)VALUES ('${lastid}','${req.body.companyname[i]}','${req.body.designation[i]}','${req.body.from[i]}','${req.body.to[i]}')`,(err)=>{
                if(err) throw err;
            })
        }
    }
    //language

    if(req.body.language != undefined){
        for (i=0;i<req.body.language.length;i++){
            if(req.body.language[i]!=""){
                let read=req.body[req.body.language[i]+"_read"];
                let speak=req.body[req.body.language[i]+"_speak"];
                let write=req.body[req.body.language[i]+"_write"];
                console.log(read,"read",speak,"speak","****************************************************************")
                if(read==undefined){
                    read=0;
                }
                if(speak==undefined){
                    speak=0;
                }
                if(write==undefined){
                    write=0;
                }
            

                // req.body.language[i]
                db.query(`INSERT INTO LanguageMaster ( lanvalue, read_test, speak, write_test, empid) VALUES ('${req.body.language[i]}','${read}','${speak}','${write}','${lastid}');`,(err)=>{
                    if(err) throw err;
                })
            }
        }
    }
    //technology

    var sqltech=`INSERT INTO TechnologyMaster (techvalue,techproficiency,empid) VALUES (?,?, '${lastid}')`;

    if(req.body.technology[0]){
        db.query(sqltech,[req.body.technology[0],req.body.phpkn]);
    }
    if(req.body.technology[1]){
        db.query(sqltech,[req.body.technology[1],req.body.mysqlkn]);
    }
    if(req.body.technology[2]){
        db.query(sqltech,[req.body.technology[2],req.body.laravelkn]);
    }
    if(req.body.technology[3]){
        db.query(sqltech,[req.body.technology[3],req.body.oraclekn]);
    }
    

    // references

    for(i=0;i<req.body.referencename.length;i++){
        if(req.body.referencename[i]!=""){

            db.query(`INSERT INTO ReferenceContact (name,contactnumber,relation,empid)VALUES ('${req.body.referencename[i]}','${req.body.contactnumber[i]}','${req.body.relation[i]}','${lastid}')`,(err)=>{
                if(err) throw err;
            })
        }
    }
  

    //prefere


    db.query(`INSERT INTO preferences (preferencelocation,noticeperiod,expectedCtc,currentCtc,department,empid)VALUES ('${req.body.preferdlocation}','${req.body.noticeperiod}','${req.body.expectedctc}','${req.body.currentctc}','${req.body.department}','${lastid}')`,(err)=>{
        if(err) throw err;
    })
       
 



        

   });


   res.redirect('/task12')
    
})


// task 12 end



//task 13 start



app.get("/task13",(req,res)=>{
    res.render('tasks/task13')
})
app.get("/task13/update/:id",(req,res)=>{
    res.render('tasks/task13')
})


//update 
app.post("/task13/update/:id",(req,res)=>{
    id=req.params.id
    console.log(req.body)

    db.query(`update EmployeeBasicDetails set firstname='${req.body.fname}',lastname='${req.body.lname}',designation_eb='${req.body.designationba}',phone='${req.body.phone}',gender='${req.body.radio}',email='${req.body.email}',address1='${req.body.address1}',address2='${req.body.address2}',city='${req.body.city}',state='${req.body.state}',birthdate='${req.body.DateOfBirth}' where empid='${id}'`,(err,result)=>
    {
        if(err) throw err;
    })
  
    for(i=0;i<req.body.nob.length;i++){
        if(req.body.nob[i]!=""){
            newid=req.body.edudetailid
            console.log(newid,"newid")

            db.query(`update EducationDetail set boardname='${req.body.nob[i]}', passingyear='${req.body.passingyear[i]}',percentage='${req.body.percentage[i]}' where edudetailid='${newid[i]}'`,(err,result)=>{
                if (err) throw err;
                console.log(result)
                if(err) throw err;
            })}
        
    }
    for(j=0;j<req.body.companyname.length;j++){
        if(req.body.companyname[j]!=""){
            newworkid=req.body.workid
            console.log(newworkid,"workid   ")
            db.query(`update WorkExperience set compname='${req.body.companyname[j]}',designation='${req.body.designation[j]}',durationfrom='${req.body.cfrom[j]}',durationto='${req.body.cto[j]}' where workexpid='${newworkid[j]}'`,(err,result)=>{
                if(err) throw err;
            })
        }
    }
    if(req.body.language != undefined){
        for (i=0;i<req.body.language.length;i++){
            if(req.body.language[i]!=""){
                newlanid=req.body.lanid

                let read=req.body[req.body.language[i]+"_read"];
                let speak=req.body[req.body.language[i]+"_speak"];
                let write=req.body[req.body.language[i]+"_write"];
                console.log(read,"read",speak,"speak","****************************************************************")
                if(read==undefined){
                    read=0;
                }
                if(speak==undefined){
                    speak=0;
                }
                if(write==undefined){
                    write=0;
                }
            

                // req.body.language[i]
                db.query(`update LanguageMaster set lanvalue='${req.body.language[i]}', read_test='${read}', speak='${speak}', write_test='${write}' where lanid='${newlanid[i]}'`,(err)=>{
                    if(err) throw err;
                })
            }
        }
    }

    console.log(req.body.techid[0],req.body.technology[0],"techid***************88")

    if(req.body.technology[0]){
        db.query(`update TechnologyMaster set techvalue='${req.body.technology[0]}',techproficiency='${req.body.phpkn}' where techid='${req.body.techid[0]}'`);
    }
    if(req.body.technology[1]){
        db.query(`update TechnologyMaster set techvalue='${req.body.technology[1]}',techproficiency='${req.body.mysqlkn}' where techid='${req.body.techid[1]}'`);
    }
    if(req.body.technology[2]){
        db.query(`update TechnologyMaster set techvalue='${req.body.technology[2]}',techproficiency='${req.body.laravelkn}' where techid='${req.body.techid[2]}'`);
    }
    if(req.body.technology[3]){
        db.query(`update TechnologyMaster set techvalue='${req.body.technology[3]}',techproficiency='${req.body.oraclekn}' where techid='${req.body.techid[3]}'`);
    }

    for(i=0;i<req.body.referencename.length;i++){

        if(req.body.referencename[i]!=""){
            newrefid=req.body.refid

            db.query(`update ReferenceContact set name='${req.body.referencename[i]}',contactnumber='${req.body.contactnumber[i]}',relation='${req.body.relation[i]}' where refid='${newrefid[i]}'`,(err)=>{
                if(err) throw err;
            })
        }
    }
    db.query(`update preferences set preferencelocation='${req.body.preferdlocation}',noticeperiod='${req.body.noticeperiod}',expectedCtc='${req.body.expectedctc}',currentCtc='${req.body.currentctc}',department='${req.body.department}' where preferenceid='${req.body.preferenceid}'`,(err)=>{
        if(err) throw err;
    })
    })

//update end


app.post("/task13/register_data",(req,res)=>{
    fname=req.body.fname
    lname=req.body.lname
    dg=req.body.designationba
    phone=req.body.phone
    email=req.body.email
    address1=req.body.address1
    address2=req.body.address2
    city=req.body.city
    state=req.body.states
    birthdate=req.body.DateOfBirth
    gender=req.body.radio


    console.log(req.body,"added data")


   db.query(`INSERT INTO EmployeeBasicDetails (firstname, lastname, designation_eb, phone, gender,email,address1,address2,city,state,birthdate) VALUES('${fname}','${lname}','${dg}','${phone}','${gender}','${email}','${address1}','${address2}','${city}','${state}','${birthdate}')`,(err,result)=>{
    if (err) throw err;
    lastid=result.insertId

    //insert education section details
    for(i=0;i<req.body.nob.length;i++){
        if(req.body.nob[i]!=""){

            db.query(`INSERT INTO EducationDetail(empid,boardname,passingyear, percentage) VALUES ('${lastid}', '${req.body.nob[i]}', '${req.body.passingyear[i]}','${req.body.percentage[i]}')`,(err,result)=>{
                if (err) throw err;
            })
        }
    }
    // work experience
    for(i=0;i<req.body.companyname.length;i++){
        if(req.body.companyname[i]!=""){

            db.query(`INSERT INTO WorkExperience(empid,compname,designation,durationfrom,durationto)VALUES ('${lastid}','${req.body.companyname[i]}','${req.body.designation[i]}','${req.body.cfrom[i]}','${req.body.cto[i]}')`,(err)=>{
                if(err) throw err;
            })
        }
    }
    //language

    if(req.body.language != undefined){
        for (i=0;i<req.body.language.length;i++){
            if(req.body.language[i]!=""){
                let read=req.body[req.body.language[i]+"_read"];
                let speak=req.body[req.body.language[i]+"_speak"];
                let write=req.body[req.body.language[i]+"_write"];
                // console.log(read,"read",speak,"speak","****************************************************************")
                if(read==undefined){
                    read=0;
                }
                if(speak==undefined){
                    speak=0;
                }
                if(write==undefined){
                    write=0;
                }
            

                // req.body.language[i]
                db.query(`INSERT INTO LanguageMaster ( lanvalue, read_test, speak, write_test, empid) VALUES ('${req.body.language[i]}','${read}','${speak}','${write}','${lastid}');`,(err)=>{
                    if(err) throw err;
                })
            }
        }
    }


    var sqltech=`INSERT INTO TechnologyMaster (techvalue,techproficiency,empid) VALUES (?,?, '${lastid}')`;

    if(req.body.technology[0]){
        db.query(sqltech,[req.body.technology[0],req.body.phpkn]);
    }
    if(req.body.technology[1]){
        db.query(sqltech,[req.body.technology[1],req.body.mysqlkn]);
    }
    if(req.body.technology[2]){
        db.query(sqltech,[req.body.technology[2],req.body.laravelkn]);
    }
    if(req.body.technology[3]){
        db.query(sqltech,[req.body.technology[3],req.body.oraclekn]);
    }
    

    // references

    for(i=0;i<req.body.referencename.length;i++){
        if(req.body.referencename[i]!=""){

            db.query(`INSERT INTO ReferenceContact (name,contactnumber,relation,empid)VALUES ('${req.body.referencename[i]}','${req.body.contactnumber[i]}','${req.body.relation[i]}','${lastid}')`,(err)=>{
                if(err) throw err;
            })
        }
    }
  

    //prefere


    db.query(`INSERT INTO preferences (preferencelocation,noticeperiod,expectedCtc,currentCtc,department,empid)VALUES ('${req.body.preferdlocation}','${req.body.noticeperiod}','${req.body.expectedctc}','${req.body.currentctc}','${req.body.department}','${lastid}')`,(err)=>{
        if(err) throw err;
    })
       
})
    res.redirect('/task13')
})

app.get('/task13/candidate/:id',(req,res)=>{
    id=req.params.id
    db.query(`SELECT firstname as fname,lastname as lname,address1,address2,gender,designation_eb as designationba,email,city,state,birthdate as DateOfBirth,phone FROM EmployeeBasicDetails where empid='${id}'`,(err,row,fields)=>{
        if (err) throw err;
        res.json(row)

})
})

app.get('/task13/education/:id',(req,res)=>{
    id=req.params.id
    db.query(`SELECT edudetailid,boardname as nob,passingyear,percentage FROM EducationDetail where empid='${id}'`,(err,rowedu)=>{
        if(err)throw err;
        res.json(rowedu)
        
})
})
app.get('/task13/work/:id',(req,res)=>{
    id=req.params.id
    db.query(`SELECT workexpid as workid, compname as companyname,designation,durationfrom as cfrom,durationto as cto FROM WorkExperience where empid='${id}'`,(err,rowwork)=>{
        if(err)throw err;
        res.json(rowwork)
        
})
})
app.get('/task13/language/:id',(req,res)=>{
    id=req.params.id
    db.query(`SELECT lanid,lanvalue as language,read_test as languageread ,write_test as languagewrite ,speak as languagespeak FROM LanguageMaster where empid='${id}'`,(err,row2)=>{
        if (err) throw err;
        res.json(row2)
        
})
})
app.get('/task13/tech/:id',(req,res)=>{
    id=req.params.id
    db.query(`SELECT techid,techvalue,techproficiency FROM TechnologyMaster where empid='${id}'`,(err,row3)=>{
        if (err) throw err;
        res.json(row3)
        
})
})
app.get('/task13/ref/:id',(req,res)=>{
    id=req.params.id
    db.query(`SELECT refid,name as referencename,contactnumber,relation FROM ReferenceContact where empid='${id}'`,(err,rowref)=>{
        if (err) throw err;
        res.json(rowref)
        
})
})
app.get('/task13/pre/:id',(req,res)=>{
    id=req.params.id
    db.query(`SELECT preferenceid,preferencelocation as preferdlocation,noticeperiod,expectedCtc as expectedctc ,currentCtc as currentctc,department FROM preferences where empid='${id}'`,(err,rowpre)=>{
        if (err) throw err;
        res.json(rowpre)
        
})
})

// task 13 end








































app.listen(port,()=>{
    console.log(`http://127.0.0.1:${port}/`)
})


