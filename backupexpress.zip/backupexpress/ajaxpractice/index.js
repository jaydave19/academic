const express =require('express')
const app=express()
const port=8099

var bodyParser=require("body-parser"); 
app.set('view engine','ejs');

var mysql = require('mysql');
const { Result } = require('express-validator');
const e = require('express');
app.use(bodyParser.urlencoded({extended:true})); 
app.use(express.static('public'))


var db = mysql.createConnection({
    host     : 'localhost',
    user     : 'root',
    password : 'root',
    // database:'test',
    database : 'newdesignemployee',
    dateStrings:true
});


app.get("/stepform",(req,res)=>{
    res.render('stepform')
})
app.get("/stepform/update/:id",(req,res)=>{
    res.render('stepform')
})


//update 
app.post("/stepform/update/:id",(req,res)=>{
    id=req.params.id
    console.log(req.body)

    db.query(`update EmployeeBasicDetails set firstname='${req.body.fname}',lastname='${req.body.lname}',designation_eb='${req.body.designationba}',phone='${req.body.phone}',gender='${req.body.radio}',email='${req.body.email}',address1='${req.body.address1}',address2='${req.body.address2}',city='${req.body.city}',state='${req.body.state}',birthdate='${req.body.DateOfBirth}' where empid='${id}'`,(err,result)=>
    {
        if(err) throw err;
    })
  
    for(i=0;i<req.body.nob.length;i++){
        if(req.body.nob[i]!=""){
            newid=req.body.edudetailid
            console.log(newid,"newid")

            db.query(`update EducationDetail set boardname='${req.body.nob[i]}', passingyear='${req.body.passingyear[i]}',percentage='${req.body.percentage[i]}' where edudetailid='${newid[i]}'`,(err,result)=>{
                if (err) throw err;
                console.log(result)
                if(err) throw err;
            })}
        
    }
    for(j=0;j<req.body.companyname.length;j++){
        if(req.body.companyname[j]!=""){
            newworkid=req.body.workid
            console.log(newworkid,"workid   ")
            db.query(`update WorkExperience set compname='${req.body.companyname[j]}',designation='${req.body.designation[j]}',durationfrom='${req.body.cfrom[j]}',durationto='${req.body.cto[j]}' where workexpid='${newworkid[j]}'`,(err,result)=>{
                if(err) throw err;
            })
        }
    }
    if(req.body.language != undefined){
        for (i=0;i<req.body.language.length;i++){
            if(req.body.language[i]!=""){
                newlanid=req.body.lanid

                let read=req.body[req.body.language[i]+"_read"];
                let speak=req.body[req.body.language[i]+"_speak"];
                let write=req.body[req.body.language[i]+"_write"];
                console.log(read,"read",speak,"speak","****************************************************************")
                if(read==undefined){
                    read=0;
                }
                if(speak==undefined){
                    speak=0;
                }
                if(write==undefined){
                    write=0;
                }
            

                // req.body.language[i]
                db.query(`update LanguageMaster set lanvalue='${req.body.language[i]}', read_test='${read}', speak='${speak}', write_test='${write}' where lanid='${newlanid[i]}'`,(err)=>{
                    if(err) throw err;
                })
            }
        }
    }

    console.log(req.body.techid[0],req.body.technology[0],"techid***************88")

    if(req.body.technology[0]){
        db.query(`update TechnologyMaster set techvalue='${req.body.technology[0]}',techproficiency='${req.body.phpkn}' where techid='${req.body.techid[0]}'`);
    }
    if(req.body.technology[1]){
        db.query(`update TechnologyMaster set techvalue='${req.body.technology[1]}',techproficiency='${req.body.mysqlkn}' where techid='${req.body.techid[1]}'`);
    }
    if(req.body.technology[2]){
        db.query(`update TechnologyMaster set techvalue='${req.body.technology[2]}',techproficiency='${req.body.laravelkn}' where techid='${req.body.techid[2]}'`);
    }
    if(req.body.technology[3]){
        db.query(`update TechnologyMaster set techvalue='${req.body.technology[3]}',techproficiency='${req.body.oraclekn}' where techid='${req.body.techid[3]}'`);
    }

    for(i=0;i<req.body.referencename.length;i++){

        if(req.body.referencename[i]!=""){
            newrefid=req.body.refid

            db.query(`update ReferenceContact set name='${req.body.referencename[i]}',contactnumber='${req.body.contactnumber[i]}',relation='${req.body.relation[i]}' where refid='${newrefid[i]}'`,(err)=>{
                if(err) throw err;
            })
        }
    }
    db.query(`update preferences set preferencelocation='${req.body.preferdlocation}',noticeperiod='${req.body.noticeperiod}',expectedCtc='${req.body.expectedctc}',currentCtc='${req.body.currentctc}',department='${req.body.department}' where preferenceid='${req.body.preferenceid}'`,(err)=>{
        if(err) throw err;
    })
    })

//update end


app.post("/stepform/register_data",(req,res)=>{
    fname=req.body.fname
    lname=req.body.lname
    dg=req.body.designationba
    phone=req.body.phone
    email=req.body.email
    address1=req.body.address1
    address2=req.body.address2
    city=req.body.city
    state=req.body.states
    birthdate=req.body.DateOfBirth
    gender=req.body.radio


    console.log(req.body,"added data")


   db.query(`INSERT INTO EmployeeBasicDetails (firstname, lastname, designation_eb, phone, gender,email,address1,address2,city,state,birthdate) VALUES('${fname}','${lname}','${dg}','${phone}','${gender}','${email}','${address1}','${address2}','${city}','${state}','${birthdate}')`,(err,result)=>{
    if (err) throw err;
    lastid=result.insertId

    //insert education section details
    for(i=0;i<req.body.nob.length;i++){
        if(req.body.nob[i]!=""){

            db.query(`INSERT INTO EducationDetail(empid,boardname,passingyear, percentage) VALUES ('${lastid}', '${req.body.nob[i]}', '${req.body.passingyear[i]}','${req.body.percentage[i]}')`,(err,result)=>{
                if (err) throw err;
            })
        }
    }
    // work experience
    for(i=0;i<req.body.companyname.length;i++){
        if(req.body.companyname[i]!=""){

            db.query(`INSERT INTO WorkExperience(empid,compname,designation,durationfrom,durationto)VALUES ('${lastid}','${req.body.companyname[i]}','${req.body.designation[i]}','${req.body.cfrom[i]}','${req.body.cto[i]}')`,(err)=>{
                if(err) throw err;
            })
        }
    }
    //language

    if(req.body.language != undefined){
        for (i=0;i<req.body.language.length;i++){
            if(req.body.language[i]!=""){
                let read=req.body[req.body.language[i]+"_read"];
                let speak=req.body[req.body.language[i]+"_speak"];
                let write=req.body[req.body.language[i]+"_write"];
                // console.log(read,"read",speak,"speak","****************************************************************")
                if(read==undefined){
                    read=0;
                }
                if(speak==undefined){
                    speak=0;
                }
                if(write==undefined){
                    write=0;
                }
            

                // req.body.language[i]
                db.query(`INSERT INTO LanguageMaster ( lanvalue, read_test, speak, write_test, empid) VALUES ('${req.body.language[i]}','${read}','${speak}','${write}','${lastid}');`,(err)=>{
                    if(err) throw err;
                })
            }
        }
    }


    var sqltech=`INSERT INTO TechnologyMaster (techvalue,techproficiency,empid) VALUES (?,?, '${lastid}')`;

    if(req.body.technology[0]){
        db.query(sqltech,[req.body.technology[0],req.body.phpkn]);
    }
    if(req.body.technology[1]){
        db.query(sqltech,[req.body.technology[1],req.body.mysqlkn]);
    }
    if(req.body.technology[2]){
        db.query(sqltech,[req.body.technology[2],req.body.laravelkn]);
    }
    if(req.body.technology[3]){
        db.query(sqltech,[req.body.technology[3],req.body.oraclekn]);
    }
    

    // references

    for(i=0;i<req.body.referencename.length;i++){
        if(req.body.referencename[i]!=""){

            db.query(`INSERT INTO ReferenceContact (name,contactnumber,relation,empid)VALUES ('${req.body.referencename[i]}','${req.body.contactnumber[i]}','${req.body.relation[i]}','${lastid}')`,(err)=>{
                if(err) throw err;
            })
        }
    }
  

    //prefere


    db.query(`INSERT INTO preferences (preferencelocation,noticeperiod,expectedCtc,currentCtc,department,empid)VALUES ('${req.body.preferdlocation}','${req.body.noticeperiod}','${req.body.expectedctc}','${req.body.currentctc}','${req.body.department}','${lastid}')`,(err)=>{
        if(err) throw err;
    })
       
})
    res.redirect('stepform')
})

app.get('/stepform/candidate/:id',(req,res)=>{
    id=req.params.id
    db.query(`SELECT firstname as fname,lastname as lname,address1,address2,gender,designation_eb as designationba,email,city,state,birthdate as DateOfBirth,phone FROM EmployeeBasicDetails where empid='${id}'`,(err,row,fields)=>{
        if (err) throw err;
        res.json(row)

})
})

app.get('/stepform/education/:id',(req,res)=>{
    id=req.params.id
    db.query(`SELECT edudetailid,boardname as nob,passingyear,percentage FROM EducationDetail where empid='${id}'`,(err,rowedu)=>{
        if(err)throw err;
        res.json(rowedu)
        
})
})
app.get('/stepform/work/:id',(req,res)=>{
    id=req.params.id
    db.query(`SELECT workexpid as workid, compname as companyname,designation,durationfrom as cfrom,durationto as cto FROM WorkExperience where empid='${id}'`,(err,rowwork)=>{
        if(err)throw err;
        res.json(rowwork)
        
})
})
app.get('/stepform/language/:id',(req,res)=>{
    id=req.params.id
    db.query(`SELECT lanid,lanvalue as language,read_test as languageread ,write_test as languagewrite ,speak as languagespeak FROM LanguageMaster where empid='${id}'`,(err,row2)=>{
        if (err) throw err;
        res.json(row2)
        
})
})
app.get('/stepform/tech/:id',(req,res)=>{
    id=req.params.id
    db.query(`SELECT techid,techvalue,techproficiency FROM TechnologyMaster where empid='${id}'`,(err,row3)=>{
        if (err) throw err;
        res.json(row3)
        
})
})
app.get('/stepform/ref/:id',(req,res)=>{
    id=req.params.id
    db.query(`SELECT refid,name as referencename,contactnumber,relation FROM ReferenceContact where empid='${id}'`,(err,rowref)=>{
        if (err) throw err;
        res.json(rowref)
        
})
})
app.get('/stepform/pre/:id',(req,res)=>{
    id=req.params.id
    db.query(`SELECT preferenceid,preferencelocation as preferdlocation,noticeperiod,expectedCtc as expectedctc ,currentCtc as currentctc,department FROM preferences where empid='${id}'`,(err,rowpre)=>{
        if (err) throw err;
        res.json(rowpre)
        
})
})

// app.get('/',(req,res)=>{
//     res.render('state')
// })
// app.get('/states',(req,res)=>{
//     db.query('select * from states',(err,result)=>{
//         if (err) throw err;
//         console.log(result,"ressttswat  ")
//         res.json(result)
//     })
// })
// app.get('/cities/:id',(req,res)=>{
//     id=req.params.id
//     db.query(`select * from cities where state_id=${id}`,(err,result)=>{
//         if (err) throw err;
//         console.log(result,"ressttswat  ")
//         res.json(result)
//     })
// })

app.listen(port,()=>{
    console.log(`listening port is ${port}`)
})