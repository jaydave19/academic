
function emailcheck() {
    email = document.getElementById('email').value
    var validRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    er = document.getElementById('email_error');
    if (email == "") {
        er.innerHTML = ("please enter email");
        return false
    }

    else {
        er.innerHTML = ("")
        if (!validRegex.test(email)) {
            // er.innerHTML = ("")
            er.innerHTML = ("Invalid email address!");
            return false
        }
        return true

    }
}

function fnamecheck() {
    firstname = document.getElementById('fname').value
    er_f = document.getElementById('firstname_error');

    if (firstname == "") {
        er_f.innerHTML = "please enter firstname"
        return false

    }
    else {
        er_f.innerHTML = ""
        return true
    }
}
function lnamecheck() {
    lastname = document.getElementById('lname').value
    er_lf = document.getElementById('lastname_error');

    if (lastname == "") {
        er_lf.innerHTML = "please enter lastname"
        return false

    }
    else {
        er_lf.innerHTML = ""
        return true
            }

}
function addresscheck() {
    address1 = document.getElementById("address1").value
    err_add = document.getElementById('address1_error');

    if (address1 == "") {
        err_add.innerHTML = "please enter address1"
        return false

    }
    else {
        err_add.innerHTML = ""        
        return true

    }
}
function address2check() {
    address2 = document.getElementById("address2").value
    err_add2 = document.getElementById('address2_error');

    if (address2 == "") {
        err_add2.innerHTML = "please enter address2"
        return false


    }
    else {
        err_add2.innerHTML = ""
        return true
    }
}
function citycheck() {
    city = document.getElementById('city').value
    er_city = document.getElementById('city_error');

    if (city == "") {
        er_city.innerHTML = "please enter city"
        return false

    }
    else {
        er_city.innerHTML = ""
        return true
    }
}
function designationcheck() {
    des_ignation= document.getElementById('designationba').value
    er_designation = document.getElementById('designation_error');

    if (des_ignation == "") {
        er_designation.innerHTML = "please enter designation"
        return false

    }
    else {
        er_designation.innerHTML = ""
        return true
    }
}
function gendercheck() {
    var option = document.getElementsByName('radio');
    var gender_err = document.getElementById('gender_error')
    if (!(option[0].checked || option[1].checked)) {
        gender_err.innerHTML = ("Please Select Your Gender");
        return false;
    }
    else {
        gender_err.innerHTML = ""
        return true
    }

}
function statecheck() {
    var option = document.getElementById('state1').value;
    console.log(option);
    var state_err = document.getElementById('state_error');

    if (option == 'select') {
        state_err.innerHTML = ("please select another one ")
        return false;
    }
    else {
        state_err.innerHTML = ""
        return true
    }
}

function datecheck() {
    var date_regex = /^(19|20)\d{2}-(0[1-9]|1[0-2])-(0[1-9]|1\d|2\d|3[01])$/;
    var date = document.getElementById('DateOfBirth').value
    console.log(date, "dfate is ")
    if (date == "") {
        birth_error.innerHTML = ("please enter date");
        return false
    }

    else {
        birth_error.innerHTML = ""
        if (!date_regex.test(date)) {
            // birth_error.innerHTML = ""
            birth_error.innerHTML = "enter date on given formate "
            return false;
        }
        return true
    }
}
function phonecheck() {
    var phone_regex = /^[6-9][0-9]{9}$/;
    var phone = document.getElementById('phone').value
    if (phone == "") {
        phone_error.innerHTML = ('please enter phone number')
        return false
    }
    else {
        phone_error.innerHTML = ""
        if (!phone_regex.test(phone)) {
            // phone_error.innerHTML = ""
            phone_error.innerHTML = "phone number must be 10 digit"
            return false

        }
        return true
    }
}


function ssccheck1() {
    boardname = document.getElementById('boardname1').value
    bord_error = document.getElementById("ssc_error1");

    if (boardname == '') {
        bord_error.innerHTML = ("please enter boardname")
        return false;
    }
    else {
        bord_error.innerHTML = ""
        return true;
    }
}





function sscFun()
{
    console.log("sscmain")
    boardname = document.getElementById('boardname1').value
    sscyear = document.getElementById('passingyearssc').value
    sscpercentage=document.getElementById('percentagessc').value

    if(boardname != "")
    {
        sscyearcheck()
        return sscpercentagecheck()
    }

    if(sscyear != "")
    {
        ssccheck1()
        return sscpercentagecheck()
    }

    if(sscpercentage != "")
    {
        ssccheck1()
        return sscyearcheck()
    }

}

function hscFun()
{
    boardname2 = document.getElementById('boardname2').value
    hscyear = document.getElementById('passingyearhsc').value
    hscpercentage=document.getElementById('percentagehsc').value


    if(boardname2 != "")
    {
       hscyearcheck()
       return hscpercentagecheck()
    }

    if(hscyear != "")
    {
       hsccheck1()
       return hscpercentagecheck()
    }

    if(hscpercentage != "")
    {
       hsccheck1()
       return hscyearcheck()
    }

}


function sscyearcheck() {
    sscyear = document.getElementById('passingyearssc').value
    year_error = document.getElementById("ssc_error2");
    var year_regex=/^(19[5-9]\d|20[0-4]\d|2050)$/

    if (sscyear == '') {
        year_error.innerHTML = ("please enter year")
        return false;
    }
    else {
        year_error.innerHTML = ""
        if(!year_regex.test(sscyear)){
            year_error.innerHTML = ""
            year_error.innerHTML="enter valid year formate"
            return false
        }
        return true
    }
}

function sscpercentagecheck(){
    console.log("sscpercentage")
    sscpercentage=document.getElementById('percentagessc').value
    per_err=document.getElementById('ssc_error3');
    var per_regex=/^([3-9]([0-9]))(\.[0-9]{1,2})$/
    var sscnewpr=parseFloat(sscpercentage)
    console.log(typeof(sscnewpr),"{}{}{}{}{}{}{}{{}")
    if (sscpercentage == '') {
        per_err.innerHTML = ("please enter percentage")
        return false;
    }
    else {
        per_err.innerHTML = ""
        if(!per_regex.test(sscnewpr)){
            per_err.innerHTML = ""
            per_err.innerHTML="enter valid percentage formate"
            return false
        }
        return true
    }

}



function hsccheck1() {
    boardname2 = document.getElementById('boardname2').value
    bord_error2 = document.getElementById("hsc_error1");

    if (boardname2 == '') {
        bord_error2.innerHTML = ("please enter hscboardname")
        return false;
    }
    else {
        bord_error2.innerHTML = ""
        return true;
    }
}

function hscyearcheck() {
    hscyear = document.getElementById('passingyearhsc').value
    year_error = document.getElementById("hsc_error2");
    var year_regex=/^(19[5-9]\d|20[0-4]\d|2050)$/

    if (hscyear == '') {
        year_error.innerHTML = ("please enter year")
        return false;
    }
    else {
        year_error.innerHTML = ""
        if(!year_regex.test(hscyear)){
            year_error.innerHTML = ""
            year_error.innerHTML="enter valid year formate"
            return false
        }
        return true
    }
}

function hscpercentagecheck(){
    hscpercentage=document.getElementById('percentagehsc').value
    per_err=document.getElementById('hsc_error3');
    var per_regex=/^([3-9]([0-9]))(\.[0-9]{1,2})$/
    var sscnewpr=parseFloat(hscpercentage)
    console.log(typeof(sscnewpr),"{}{}{}{}{}{}{}{{}")
    if (hscpercentage == '') {
        per_err.innerHTML = ("please enter percentage")
        return false;
    }
    else {
        per_err.innerHTML = ""
        if(!per_regex.test(sscnewpr)){
            per_err.innerHTML = ""
            per_err.innerHTML="enter valid percentage formate"
            return false
        }
        return true
    }

}
function beFun()
{
    boardname2 = document.getElementById('coursename').value
    beyear = document.getElementById('passingyearbachelor').value
    hscpercentage=document.getElementById('percentagebachelor').value


    if(boardname2 != "")
    {
       beyearcheck()
       return bepercentagecheck()
    }

    if(beyear != "")
    {
       becheck1()
       return bepercentagecheck()
    }

    if(hscpercentage != "")
    {
       becheck1()
       return beyearcheck()
    }

}
//me

function mecheck1() {
    boardname2 = document.getElementById('coursename2').value
    bord_error2 = document.getElementById("me_error1");

    if (boardname2 == '') {
        bord_error2.innerHTML = ("please enter coursename")
       
    }
    else {
        bord_error2.innerHTML = ""
        return true;
    }
}

function meyearcheck() {
    beyear = document.getElementById('passingyearme').value
    year_error = document.getElementById("me_error2");
    var year_regex=/^(19[5-9]\d|20[0-4]\d|2050)$/

    if (beyear == '') {
        year_error.innerHTML = ("please enter year")
        return false;
    }
    else {
        year_error.innerHTML = ""
        if(!year_regex.test(beyear)){
            year_error.innerHTML = ""
            year_error.innerHTML="enter valid year formate"
            return false
        }
        return true
    }
}

function mepercentagecheck(){
    hscpercentage=document.getElementById('percentageme').value
    per_err=document.getElementById('me_error3');
    var per_regex=/^([3-9]([0-9]))(\.[0-9]{1,2})$/
    var sscnewpr=parseFloat(hscpercentage)
    console.log(typeof(sscnewpr),"{}{}{}{}{}{}{}{{}")
    if (hscpercentage == '') {
        per_err.innerHTML = ("please enter percentage")
        return false;
    }
    else {
        per_err.innerHTML = ""
        if(!per_regex.test(sscnewpr)){
            per_err.innerHTML = ""
            per_err.innerHTML="enter valid percentage formate"
            return false
        }
    }

}
function meFun()
{
    boardname2 = document.getElementById('coursename2').value
    beyear = document.getElementById('passingyearme').value
    hscpercentage=document.getElementById('percentageme').value


    if(boardname2 != "")
    {
       meyearcheck()
       return mepercentagecheck()
    }

    if(beyear != "")
    {
       mecheck1()
       return mepercentagecheck()
    }

    if(hscpercentage != "")
    {
       mecheck1()
       return meyearcheck()
    }

}


function becheck1() {
    boardname2 = document.getElementById('coursename').value
    bord_error2 = document.getElementById("be_error1");

    if (boardname2 == '') {
        bord_error2.innerHTML = ("please enter coursename")
       
    }
    else {
        bord_error2.innerHTML = ""
        return true;
    }
}

function beyearcheck() {
    beyear = document.getElementById('passingyearbachelor').value
    year_error = document.getElementById("beyear_error2");
    var year_regex=/^(19[5-9]\d|20[0-4]\d|2050)$/

    if (beyear == '') {
        year_error.innerHTML = ("please enter year")
        return false;
    }
    else {
        year_error.innerHTML = ""
        if(!year_regex.test(beyear)){
            year_error.innerHTML = ""
            year_error.innerHTML="enter valid year formate"
            return false
        }
        return true
    }
}

function bepercentagecheck(){
    hscpercentage=document.getElementById('percentagebachelor').value
    per_err=document.getElementById('beyearper_error2');
    var per_regex=/^([3-9]([0-9]))(\.[0-9]{1,2})$/
    var sscnewpr=parseFloat(hscpercentage)
    console.log(typeof(sscnewpr),"{}{}{}{}{}{}{}{{}")
    if (hscpercentage == '') {
        per_err.innerHTML = ("please enter percentage")
        return false;
    }
    else {
        per_err.innerHTML = ""
        if(!per_regex.test(sscnewpr)){
            per_err.innerHTML = ""
            per_err.innerHTML="enter valid percentage formate"
            return false
        }
    }

}
function companyrow1()
{
    companyname1 = document.getElementById('companyname1').value
    dg1=document.getElementById('designation1').value
    date = document.getElementById('from1').value
    date2 = document.getElementById('to1').value



    if(companyname1 != "")
    {
        designation(dg1,des1_err1)
        from1()
        return to1()
    }

    if(dg1 != "")
    {
       com1() 
       from1()
       return to1()
    }

    if(date != "")
    {
        com1() 
        designation(dg1,des1_err1)
        return to1()

    }

    if(date2 != "")
    {
        com1() 
        designation(dg1,des1_err1)
        return from1()

    }


}
function companyrow2()
{
    companyname2 = document.getElementById('companyname2').value
    dg2=document.getElementById('designation2').value
    date = document.getElementById('from2').value
    date2 = document.getElementById('to2').value



    if(companyname2 != "")
    {
        designation(dg2,des2_err1)
        from2()
        return to2()
    }

    if(dg2 != "")
    {
       com2() 
       from2()
       return to2()
    }

    if(date != "")
    {
        com2() 
        designation(dg2,des2_err1)
        return to2()

    }

    if(date2 != "")
    {
        com2() 
        designation(dg2,des2_err1)
        return from2()

    }


}
function companyrow3()
{
    companyname3 = document.getElementById('companyname3').value
    dg3=document.getElementById('designation3').value
    date = document.getElementById('from3').value
    date2 = document.getElementById('to3').value



    if(companyname3 != "")
    {
        designation(dg3,des3_err1)
        from3()
        return to3()
    }

    if(dg3 != "")
    {
       com3() 
       from3()
       return to3()
    }

    if(date != "")
    {
        com3() 
        designation(dg3,des3_err1)
        return to3()

    }

    if(date2 != "")
    {
        com3() 
        designation(dg3,des3_err1)
        return from3()

    }


}
var dg1=document.getElementById('designation1').value
var des1_err1=document.getElementById('des1_err1')
var dg2=document.getElementById('designation2').value
var des2_err1=document.getElementById('des_err2')
var dg3=document.getElementById('designation3').value
var des3_err1=document.getElementById('des1_err3')

function designation(id,err) {
 
    if(id==''){
        err.innerHTML="enter designation"
        return false
    }
    else {
        err.innerHTML=""
    }
}
function com1() {
    companyname1 = document.getElementById('companyname1').value
    com1_err1 = document.getElementById("com1_err1");
 
    if (companyname1 == '') {
        com1_err1.innerHTML = ("please enter companyname")
        return false
    }
  
    else {
            com1_err1.innerHTML = ""
    }
}
function com2() {
    companyname1 = document.getElementById('companyname2').value
    com1_err1 = document.getElementById("com_err2");

    if (companyname1 == '') {
        com1_err1.innerHTML = ("please enter companyname")
        return false
    }

    else {
            com1_err1.innerHTML = ""
      
    

    }
}
function com3() {
    companyname1 = document.getElementById('companyname3').value
    com1_err1 = document.getElementById("com1_err3");
    
    if (companyname1 == '') {
        com1_err1.innerHTML = ("please enter companyname")

        return false;
    }

    else {
  

            com1_err1.innerHTML = ""
    

    }
}
function from1(){
    var date_regex = /^(19|20)\d{2}-(0[1-9]|1[0-2])-(0[1-9]|1\d|2\d|3[01])$/;
    var date = document.getElementById('from1').value
    console.log(date, "dfate is ")
    if (date == "") {
        from1_err1.innerHTML = ("please enter date");
        return false
    }

    else {
        from1_err1.innerHTML = ""
        if (!date_regex.test(date)) {
            from1_err1.innerHTML = ""
            from1_err1.innerHTML = "enter date on given formate "
            return false;
        }
    }
}
function to1(){
    var date_regex = /^(19|20)\d{2}-(0[1-9]|1[0-2])-(0[1-9]|1\d|2\d|3[01])$/;
    var date = document.getElementById('to1').value
    console.log(date, "dfate is ")
    if (date == "") {
        to1_err1.innerHTML = ("please enter date");
        return false
    }

    else {
        to1_err1.innerHTML = ""
        if (!date_regex.test(date)) {
            to1_err1.innerHTML = ""
            to1_err1.innerHTML = "enter date on given formate "
            return false;
        }
    }
}
function from2(){
    var date_regex = /^(19|20)\d{2}-(0[1-9]|1[0-2])-(0[1-9]|1\d|2\d|3[01])$/;
    var date = document.getElementById('from2').value
    console.log(date, "dfate is ")
    if (date == "") {
        from1_err2.innerHTML = ("please enter date");
        return false
    }

    else {
        from1_err2.innerHTML = ""
        if (!date_regex.test(date)) {
            from1_err2.innerHTML = ""
            from1_err2.innerHTML = "enter date on given formate "
            return false;
        }
    }
}
function to2(){
    var date_regex = /^(19|20)\d{2}-(0[1-9]|1[0-2])-(0[1-9]|1\d|2\d|3[01])$/;
    var date = document.getElementById('to2').value
    console.log(date, "dfate is ")
    if (date == "") {
        to1_err2.innerHTML = ("please enter date");
        return false
    }

    else {
        to1_err2.innerHTML = ""
        if (!date_regex.test(date)) {
            to1_err2.innerHTML = ""
            to1_err2.innerHTML = "enter date on given formate "
            return false;
        }
    }
}
function from3(){
    var date_regex = /^(19|20)\d{2}-(0[1-9]|1[0-2])-(0[1-9]|1\d|2\d|3[01])$/;
    var date = document.getElementById('from3').value
    console.log(date, "dfate is ")
    if (date == "") {
        from1_err3.innerHTML = ("please enter date");
        return false
    }

    else {
        from1_err3.innerHTML = ""
        if (!date_regex.test(date)) {
            from1_err3.innerHTML = ""
            from1_err3.innerHTML = "enter date on given formate "
            return false;
        }
    }
}
function to3(){
    var date_regex = /^(19|20)\d{2}-(0[1-9]|1[0-2])-(0[1-9]|1\d|2\d|3[01])$/;
    var date = document.getElementById('to3').value
    console.log(date, "dfate is ")
    if (date == "") {
        to1_err3.innerHTML = ("please enter date");
        return false
    }

    else {
        to1_err3.innerHTML = ""
        if (!date_regex.test(date)) {
            to1_err3.innerHTML = ""
            to1_err3.innerHTML = "enter date on given formate "
            return false;
        }
    }
}

function first_lan(lang,name){

    if (lang.checked){ 
        
        name.forEach(element => {
             element.disabled=false;
            })
        return false
    }
    else{
        name.forEach(element => {
            element.disabled=true;
           })
        return false 
    }
    
  
}

function checkvalue(lang,error,name){
    var boxmark=[]

    if (lang.checked){
    name.forEach(element => {
        if(element.checked){
               boxmark.push(element);
            
        }
        if(!boxmark.length>=1){
            error.innerHTML="please select at least one"
        }
        else{
            error.innerHTML=""
        }
    })
}
    else{
        error.innerHTML=""
    }

}

//reference section 
var ref1=document.querySelector('#referencename').value

var referror=document.getElementById('refname_error')
var ref2=document.getElementById('referencename2').value
var referror2=document.getElementById('refname_error2')

var rl1=document.getElementById('relation1').value
var rlerror1=document.getElementById('refrelaerr3')
var rl2=document.getElementById('relation2').value
var rlferror2=document.getElementById('refrelaerr3_2')

var phonerel = document.getElementById('contactnumber').value
var phoneerrrel=document.getElementById('refcon_error')
var phonerel2 = document.getElementById('contactnumber2').value
var phoneerrrel2=document.getElementById('refcon_error2')

function reference1(id1,err1){
    if(id1==""){
        err1.innerHTML="please enter value"
        return false
    }
    else{
        err1.innerHTML=""
    }
}

function relation1(id2,err2){
    if(id2==""){
        err2.innerHTML="please enter value"
        return false
    }
    else{
        err2.innerHTML=""
    }
}


function relphonecheck1(phid1,pherr1) {
    var phone_regex = /^[6-9][0-9]{9}$/;
    if (phid1 == "") {
        pherr1.innerHTML = ('please enter phone number')
        return false
    }
    else {
        pherr1.innerHTML = ""
        if (!phone_regex.test(phid1)) {
            // phone_error.innerHTML = ""
            pherr1.innerHTML = "phone number must be 10 digit"
            return false

        }
        return true
    }
}

function refrow1(){
    var ref1=document.querySelector('#referencename').value
    var rl1=document.getElementById('relation1').value
    var phonerel = document.getElementById('contactnumber').value

    console.log(ref1,"fsdafs");

    if(ref1!=""){
        console.log("1")
        relation1(rl1,rlerror1)
        relphonecheck1(phonerel,phoneerrrel)
    }
    if(rl1!=""){
        console.log("2")

        reference1(ref1,referror)
        relphonecheck1(phonerel,phoneerrrel)

    }
    if(phonerel!=""){
        reference1(ref1,referror)
        relation1(rl1,rlerror1)

    }
}
function refrow2(){
    var ref2=document.getElementById('referencename2').value
    var phonerel2 = document.getElementById('contactnumber2').value
    var rl2=document.getElementById('relation2').value

    if(ref2!=""){
        relation1(rl2,rlferror2)
        relphonecheck1(phonerel2,phoneerrrel2)
    }
    if(rl2!=""){
        reference1(ref2,referror2)
        relphonecheck1(phonerel2,phoneerrrel2)
    }
    if(phonerel2!=""){
        reference1(ref2,referror2)
        relation1(rl2,rlferror2)

    }
}
// end reference




// prefer location================================
// var optionpr = document.getElementById('preferdlocation').value;
// var prlerr = document.getElementById('prlerr');
// var optionpr1 = document.getElementById('department').value;
// var dperr = document.getElementById('dperr');

// statecheck(optionpr,state_errpr)
// statecheck(optionpr1,state_errpr1)

// function statecheck(id,err) {


//     if (id == 'select') {
//         err.innerHTML = ("please select another one ")
//         return false;
//     }
//     else {
//         err.innerHTML = ""
//         return true
//     }
// }
function pre(id,err){
    if(id==""){
        err.innerHTML="please enter value"
        // return false
    }
    else{
        err.innerHTML=""
    }
    return false
}
// var np=document.getElementById('noticeperiod').value
// var ec=document.getElementById('expectedctc').value
// var cc=document.getElementById('currentctc').value

// reference1(np,nperr)
// reference1(ec,ecerr)

// reference1(cc,ccerr)


function prefrow(){
    var np=document.getElementById('noticeperiod').value
    var ec=document.getElementById('expectedctc').value
    var cc=document.getElementById('currentctc').value
    // var optionpr = document.getElementById('preferdlocation').value;
    // var optionpr1 = document.getElementById('department').value;
    var ecerr = document.getElementById('ecerr')
    var ccerr = document.getElementById('ccerr')
    var nperr = document.getElementById('nperr')
    // var prlerr = document.getElementById('prlerr');
    // var dperr = document.getElementById('dperr');

    console.log(ref1,"fsdafs");

    if(np!=""){
        console.log("fsdfsdkfsdkh");
        pre(ec,ecerr)
        pre(cc,ccerr)
        // statecheck(optionpr,prlerr)
        // statecheck(optionpr1,dperr)
    }
    if(ec!=""){
        pre(np,nperr)
        pre(cc,ccerr)
        // statecheck(optionpr,prlerr)
        // statecheck(optionpr1,dperr)

    }
    if(cc!=""){
        pre(np,nperr)
        pre(ec,ecerr)
        // statecheck(optionpr,prlerr)
        // statecheck(optionpr1,dperr)

    }
    // if(optionpr!=""){
    //     pre(np,nperr)
    //     pre(cc,ccerr)
    //     pre(ec,ecerr)
    //     // statecheck(optionpr1,dperr)

    // }
    // if(optionpr1!=""){
    //     pre(np,nperr)
    //     pre(cc,ccerr)
    //     // statecheck(optionpr,prlerr)
    //     pre(ec,ecerr)

    // }
}

//end



var hindi=document.getElementById('hindi')
var hinerr=document.getElementById('hindierror');
var fl1=document.querySelectorAll('.checkbox');

var english=document.getElementById('english')
var engerror=document.getElementById('engerror');
var fl2=document.querySelectorAll('.en');

var gujarati=document.getElementById('gujarati')
var gjerror=document.getElementById('gjerror');
var fl3=document.querySelectorAll('.gj');

document.getElementById('hindi').setAttribute("onclick","first_lan(hindi,fl1)")
document.getElementById('english').setAttribute("onclick","first_lan(english,fl2)")
document.getElementById('gujarati').setAttribute("onclick","first_lan(gujarati,fl3)")

var php=document.getElementById('php');
var tk1=document.querySelectorAll('.tech');
var phperror=document.getElementById('phperr');

var mysql=document.getElementById('mysql');
var tk2=document.querySelectorAll('.tech2');
var mysqlerr=document.getElementById('mysqlerr');

var laravel=document.getElementById('laravel');
var tk3=document.querySelectorAll('.tech3');
var laravelerr=document.getElementById('laravelerr');

var oracle=document.getElementById('oracle');
var tk4=document.querySelectorAll('.tech4');
var oracleerr=document.getElementById('oracleerr');


document.getElementById('php').setAttribute("onclick","first_lan(php,tk1)")
document.getElementById('mysql').setAttribute("onclick","first_lan(mysql,tk2)")
document.getElementById('laravel').setAttribute("onclick","first_lan(laravel,tk3)")
document.getElementById('oracle').setAttribute("onclick","first_lan(oracle,tk4)")


function formvalidation() {

    var resf = fnamecheck();
    var resl = lnamecheck();
    var resemail = emailcheck();
    var resadd = addresscheck();
    var resadd2 = address2check();
    var resgender = gendercheck();
    var rescity = citycheck();
    var resdesi = designationcheck();
    var resstate = statecheck();
    var resdate = datecheck();
    var resphone = phonecheck();
    var ssc = sscFun()
    var hsc=hscFun()
    var be=beFun()
    var me=meFun()
    var cr1=companyrow1()
    var cr2=companyrow2()
    var cr3=companyrow3()
    var rescheckox=checkvalue(hindi,hinerr,fl1)
    var rescheckox2=checkvalue(english,engerror,fl2)
    var rescheckox3=checkvalue(gujarati,gjerror,fl3)

    var resradio1=checkvalue(php,phperror,tk1)
    var resradio2=checkvalue(mysql,mysqlerr,tk2)
    var resradio3=checkvalue(laravel,laravelerr,tk3)
    var resradio4=checkvalue(oracle,oracleerr,tk4)

    var resref1=refrow1()
    var resref2=refrow2()
    var respre=prefrow()


try{
    if (resf == false || resl == false || resemail == false || resadd == false || resadd2 == false || resgender == false || rescity == false || resdesi == false || resstate == false || resdate == false || resphone == false || ssc == false || hsc==false || be==false|| me==false || cr1==false || cr2==false || cr3==false ||rescheckox==false || rescheckox2==false || rescheckox3==false || resradio1==false  || resradio2==false  || resradio3==false  || resradio4==false ||resref1==false||resref2==false||respre==false){
     { 
        return false;
    }
  
}
}
catch(error){
    console.log(error)
}


}

count=0
function next(){
    flag=formvalidation()
    if(flag!=false){
    count++
    console.log(count,"++")
    
    switch (count) {

        case 1:

            document.getElementById('basicdetatilsdiv').setAttribute("style","display:none")
            document.getElementById('edudetailsdiv').removeAttribute("style","display")
            document.getElementById('pre').disabled=false
            break;

        case 2:

    
        
            console.log("else part")
            document.getElementById('edudetailsdiv').setAttribute("style","display:none")
            document.getElementById('workdwtailsdiv').removeAttribute("style","display")
            break;
        


        case 3:
     
    
        document.getElementById('workdwtailsdiv').setAttribute("style","display:none")
        document.getElementById('langdetailsdiv').removeAttribute("style","display")
        break;

        case 4:
        
    
        document.getElementById('langdetailsdiv').setAttribute("style","display:none")
        document.getElementById('techdetailsdiv').removeAttribute("style","display")
        break;

        case 5:
        document.getElementById('techdetailsdiv').setAttribute("style","display:none")
        document.getElementById('referencediv').removeAttribute("style","display")
        break;

        case 6:
        document.getElementById('referencediv').setAttribute("style","display:none")
        document.getElementById('preferencediv').removeAttribute("style","display")
        document.getElementById('nex').disabled=true
        document.getElementById('submit').hidden=false

        break;
        }}
        
        
}
function previous(){
    flag=formvalidation()
    if(flag!=false){
    count--
    console.log(count,"--")
    switch (count) {

        case 0:
            document.getElementById('edudetailsdiv').setAttribute("style","display:none")
            document.getElementById('basicdetatilsdiv').removeAttribute("style","display")
            document.getElementById('pre').disabled=true

            break;

        case 1:
        document.getElementById('workdwtailsdiv').setAttribute("style","display:none")
        document.getElementById('edudetailsdiv').removeAttribute("style","display")
        break;

        case 2:
        document.getElementById('langdetailsdiv').setAttribute("style","display:none")
        document.getElementById('workdwtailsdiv').removeAttribute("style","display")
        break;

        case 3:
        document.getElementById('techdetailsdiv').setAttribute("style","display:none")
        document.getElementById('langdetailsdiv').removeAttribute("style","display")
        break;

        case 4:
        document.getElementById('referencediv').setAttribute("style","display:none")
        document.getElementById('techdetailsdiv').removeAttribute("style","display")
        document.getElementById('sub').hidden

        break;

        case 5:
        document.getElementById('preferencediv').setAttribute("style","display:none")
        document.getElementById('referencediv').removeAttribute("style","display")
        document.getElementById('nex').disabled=false
        document.getElementById('submit').hidden=true





        break;
        }}
        
        
}
function add(){
    console.log("add call")

    let form=document.getElementById('form')
    let form_data=new FormData(form)

    const xhr=new XMLHttpRequest();
    xhr.open("POST","/stepform/register_data",true);
    xhr.setRequestHeader('content-type','application/x-www-form-urlencoded');

    xhr.onload=function(){
        if(this.status==200){
            console.log(this.responseText)
        }
    }
    xhr.send(new URLSearchParams(form_data));
    alert("Data Inserted")
}

const path=window.location.pathname.split("/")
const id=path[path.length-1]


function updatefun(){
    console.log("update call")
    let form=document.getElementById('form')
    let form_data=new FormData(form)

    const xhr=new XMLHttpRequest();
    xhr.open("POST",`/stepform/update/${id}`,true);
    xhr.setRequestHeader('content-type','application/x-www-form-urlencoded');

    xhr.onload=function(){
        if(this.status==200){
            console.log(this.responseText)
        }
    }
    xhr.send(new URLSearchParams(form_data));
    alert("Data Updated");
    window.location=`http://127.0.0.1:8099/stepform/update/${id}`


    }


async function fetchdb(){
    let response=await fetch(`http://127.0.0.1:8099/stepform/candidate/${id}`)
    let data=await response.json()

    var key=Object.keys(data[0]);
    key.forEach((item)=>{
        if(item=='gender'){
            let rb=document.getElementsByName('radio')
            rb.forEach((e)=>{
                if(e.value==data[0][item]){
                    e.checked=true
                }
            })
        }
        else{
            document.getElementsByName(item)[0].value=data[0][item];
        }
    })


    response=await fetch(`http://127.0.0.1:8099/stepform/education/${id}`)
    data=await response.json()
    var key=Object.keys(data);
    key.forEach(item => {
        let datakey=Object.keys(data[item])
        datakey.forEach(element => {
            document.getElementsByName(element)[item].value=data[item][element]
        });
    });

    response=await fetch(`http://127.0.0.1:8099/stepform/work/${id}`)
    data=await response.json()
    console.log(data)
    var key=Object.keys(data);
    key.forEach(item => {
        let datakey=Object.keys(data[item])
        datakey.forEach(element => {
            document.getElementsByName(element)[item].value=data[item][element]
        });
    });
    response=await fetch(`http://127.0.0.1:8099/stepform/language/${id}`)
    data=await response.json()
    let lang=document.getElementsByName('language[]')
    let lanid=document.getElementsByName('lanid')
    lang.forEach(e => {
        key=Object.keys(data);
        key.forEach(i => {
            lanid[i].value=data[i].lanid
            if(data[i].language==e.value){
                e.checked=true;
                document.getElementsByName(e.value+"_read")[0].removeAttribute('disabled')
                document.getElementsByName(e.value+"_speak")[0].removeAttribute('disabled')
                document.getElementsByName(e.value+"_write")[0].removeAttribute('disabled')
                if(data[i].languageread==1){
                    document.getElementsByName(e.value+"_read")[0].checked=true;
                }
                if(data[i].languagewrite==1){
                    document.getElementsByName(e.value+"_write")[0].checked=true;
                }
                if(data[i].languagespeak==1){
                    document.getElementsByName(e.value+"_speak")[0].checked=true;
                }
            }
        });
        
    });


    response=await fetch(`http://127.0.0.1:8099/stepform/tech/${id}`)
    data=await response.json()
    let tech=document.getElementsByName('technology[]')
    let techidform=document.getElementsByName('techid')

    tech.forEach(e => {
        techidform[0].value=data[0].techid
        techidform[1].value=data[1].techid

        techidform[2].value=data[2].techid

        techidform[3].value=data[3].techid

            if(data[0].techvalue==e.value){
                e.checked=true;
                document.getElementById("expert1").removeAttribute('disabled')
                document.getElementById("mideator1").removeAttribute('disabled')
                document.getElementById("beginer1").removeAttribute('disabled')
                if(data[0].techproficiency=='expert'){
                    document.getElementById("expert1").checked=true;
                }
                if(data[0].techproficiency=='mideator'){
                    document.getElementById("mideator1").checked=true;
                }
                if(data[0].techproficiency=='beginer'){
                    document.getElementById("beginer1").checked=true;
                }
            }
            if(data[1].techvalue==e.value){
                e.checked=true;
                document.getElementById("expert2").removeAttribute('disabled')
                document.getElementById("mideator2").removeAttribute('disabled')
                document.getElementById("beginer2").removeAttribute('disabled')
                if(data[1].techproficiency=='expert'){
                    document.getElementById("expert2").checked=true;
                }
                if(data[1].techproficiency=='mideator'){
                    document.getElementById("mideator2").checked=true;
                }
                if(data[1].techproficiency=='beginer'){
                    document.getElementById("beginer2").checked=true;
                }
            }
            if(data[2].techvalue==e.value){
                e.checked=true;
                document.getElementById("expert3").removeAttribute('disabled')
                document.getElementById("mideator3").removeAttribute('disabled')
                document.getElementById("beginer3").removeAttribute('disabled')
                if(data[2].techproficiency=='expert'){
                    document.getElementById("expert3").checked=true;
                }
                if(data[2].techproficiency=='mideator'){
                    document.getElementById("mideator3").checked=true;
                }
                if(data[2].techproficiency=='beginer'){
                    document.getElementById("beginer3").checked=true;
                }
            }
            if(data[3].techvalue==e.value){
                e.checked=true;
                document.getElementById("expert4").removeAttribute('disabled')
                document.getElementById("mideator4").removeAttribute('disabled')
                document.getElementById("beginer4").removeAttribute('disabled')
                if(data[3].techproficiency=='expert'){
                    document.getElementById("expert4").checked=true;
                }
                if(data[3].techproficiency=='mideator'){
                    document.getElementById("mideator4").checked=true;
                }
                if(data[3].techproficiency=='beginer'){
                    document.getElementById("beginer4").checked=true;
                }
            }
        
    });

    response=await fetch(`http://127.0.0.1:8099/stepform/ref/${id}`)
    data=await response.json()
    console.log(data)
    var key=Object.keys(data);
    key.forEach(item => {
        let datakey=Object.keys(data[item])
        datakey.forEach(element => {
            document.getElementsByName(element)[item].value=data[item][element]
        });
    });
    response=await fetch(`http://127.0.0.1:8099/stepform/pre/${id}`)
    data=await response.json()
    console.log(data)
    var key=Object.keys(data);
    key.forEach(item => {
        let datakey=Object.keys(data[item])
        datakey.forEach(element => {
            document.getElementsByName(element)[item].value=data[item][element]
        });
    });

    
}
let update=path[path.length-2]
if(update=='update'){
    console.log("****************************")
    fetchdb()
    document.getElementById("submit").removeAttribute("onclick")
    document.getElementById("submit").value='update'
    document.getElementById("submit").setAttribute('onclick','updatefun()')


}
