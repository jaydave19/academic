const express =require('express')
const app=express()
const port=8080

var bodyParser=require("body-parser"); 
app.set('view engine','ejs');

var mysql = require('mysql');
app.use(bodyParser.urlencoded({extended:true})); 


var connection = mysql.createConnection({
    host     : 'localhost',
    user     : 'root',
    password : 'root',
    database : 'task26feb'
});


app.get('/',(req,res)=>{
    res.render('d');

})



app.all('/main',(req,res)=>{

 
var page;

    if(req.body.str)
    {
      query =   req.body.str
    }
  
    if(req.query.str)
    {
    query = req.query.str
    }

    if(req.query.page){
        page=req.query.page;
    }
    else{
        page=1;
    }
    console.log(page)
    connection.query(query,(err,result)=>{
        if (err){
            
            return res.redirect('/');
        }

        const limit=10;
        const lastpage=Math.ceil(result.length/limit);
        const offset=(page-1)*limit;

        querynew=query + ` limit ${offset}, ${limit}`;
        console.log(querynew)
        connection.query(querynew,(err,row,fields)=>{

            res.render('dynamictable',{'col':fields,'row':row,'maxpage':lastpage,'page':page,'query':query})
        })
    });

});



app.listen(port,()=>{
    console.log(`listening port is ${port}`)
})