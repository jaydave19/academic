const express =require('express')
const app=express()
const port=8014

var bodyParser=require("body-parser"); 
app.set('view engine','ejs');


app.use(bodyParser.urlencoded({extended:true})); 






app.get('/api',(req,res)=>{
    res.render('api')
})
app.get('/api2',(req,res)=>{
    res.render('api2')
})



app.listen(port,()=>{
    console.log(`listening port is ${port}`)
})