const express =require('express')
const app=express()
const port=3000
var bodyParser=require("body-parser"); 
const { body, validationResult } = require('express-validator');

var fs = require("fs");
const url=require('url');
// Set EJS as templating engine 
app.set('view engine', 'ejs');
app.get('/',(req,res)=>{
    res.send("hello jay")
})
app.get('/func1',(req,res)=>{
    res.send("it is func1")
})
app.get('/home',(req,res)=>{
    res.render("home")
})

//use section
app.use(bodyParser.urlencoded({extended:false})); 
app.use(express.static('public'))
//

app.get('/dynamic',(req,res)=>{

    res.render('dynamic',{name:'jay'});
})
//form submission
app.get('/result',(req,res)=>{ 
    res.render('result'); 
}); 

app.get('/userform',(req,res)=>{
    res.render('userform')
})

try{
    const userdata=require("./userdata.json")
}
catch(err){
    data=[]
    fs.writeFile('userdata.json',JSON.stringify(data),(err)=>{
        if(err) throw err;
    }
    )
}
// const userdata=require("./userdata.json")


var userdata=require('./userdata.json')

function phonenumbervalid(req,res,next) {
    const phone=req.body.phonenumber
    console.log(phone,"phone nyukber is ")
    var phoneno = /^\d{10}$/;
    if((!phoneno.test(phone))) {
        console.log(phoneno.test(phone),"**************************************************8")
        res.send("phone not valid");
        } 
    else {
         next();
          }
  }
// inputtxt=req.body.phonenumber
app.post('/userform',

// body('fname','firstname should must be minimum 3 character').isLength({min:3}),
// body('lname','lastname should must be minimum 3 character').isLength({min:3}),
// body('email','emailshould be proper format').isEmail(),
phonenumbervalid,
// body('phonenumber','phone number must have 10 digits').regex(/^[0-9]{10}$/)


(req,res)=>{
    // const errors = validationResult(req);
    // if (!errors.isEmpty()) {
    //   return res.status(400).json({ errors: errors.array() });
    // }
    

    req.body["id"]=userdata.length+1
    userdata.push(req.body)
    fs.writeFile('userdata.json',JSON.stringify(userdata),function(err)
    {
        
        if (err) throw err;
        // datauser.push(arraydata)
        // Success 
        console.log("Done writing");   
    });

    // res.status(200).json({ message: 'User created successfully' });
    console.log(req.body)
    res.render('userform');

})

app.get('/userlist',(req,res)=>{
    fs.readFile('userdata.json', (err, data) => {
        if (err) throw err;
        res.render('userlist',{'data':JSON.parse(data)});
      });
    })



app.get('/userdetail',(req,res)=>{
    var parseurl=url.parse(req.url,true);
    // console.log(parseurl.query.id,"**************id")
    res.render('userdetails',{'id':parseurl.query.id,'data':userdata})
})

    





app.listen(port,()=>{
    console.log(`listening port is ${port}`)
})