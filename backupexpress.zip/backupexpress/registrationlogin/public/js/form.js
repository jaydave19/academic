
function emailcheck() {
    email = document.getElementById('email').value
    var validRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    er = document.getElementById('email_error');
    if (email == "") {
        er.innerHTML = ("please enter email");
        return false
    }

    else {
        er.innerHTML = ("")
        if (!validRegex.test(email)) {
            // er.innerHTML = ("")
            er.innerHTML = ("Invalid email address!");
            return false
        }
        return true

    }
}

function fnamecheck() {
    firstname = document.getElementById('fname').value
    er_f = document.getElementById('firstname_error');

    if (firstname == "") {
        er_f.innerHTML = "please enter firstname"
        return false

    }
    else {
        er_f.innerHTML = ""
        return true
    }
}
function lnamecheck() {
    lastname = document.getElementById('lname').value
    er_lf = document.getElementById('lastname_error');

    if (lastname == "") {
        er_lf.innerHTML = "please enter lastname"
        return false

    }
    else {
        er_lf.innerHTML = ""
        return true
            }

}
function passwordcheck() {
    password = document.getElementById("password").value
    err_add = document.getElementById('password_error');
    password_regex=/^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$/

    if (password == "") {
        err_add.innerHTML = "please enter password"
        return false

    }
    else {
        err_add.innerHTML = ""
        if (!password_regex.test(password)) {
            // birth_error.innerHTML = ""
            err_add.innerHTML = "Minimum eight characters, at least one letter, one number and one special character"
            return false;
        }
    }
}
function confirmpasswordcheck() {
    password = document.getElementById("password").value

    cpassword = document.getElementById("cpassword").value
    err_add2 = document.getElementById('cpassword_error');
    if (password!=""){
    if (cpassword != password) {
        err_add2.innerHTML = "password and confirm password must be same"
        return false


    }
    else {
        err_add2.innerHTML = ""
        return true
    }
}}
function citycheck() {
    city = document.getElementById('city').value
    er_city = document.getElementById('city_error');

    if (city == "") {
        er_city.innerHTML = "please enter city"
        return false

    }
    else {
        er_city.innerHTML = ""
        return true
    }
}

function gendercheck() {
    var option = document.getElementsByName('radio');
    var gender_err = document.getElementById('gender_error')
    if (!(option[0].checked || option[1].checked)) {
        gender_err.innerHTML = ("Please Select Your Gender");
        return false;
    }
    else {
        gender_err.innerHTML = ""
        return true
    }

}


function datecheck() {
    var date_regex = /^(19|20)\d{2}-(0[1-9]|1[0-2])-(0[1-9]|1\d|2\d|3[01])$/;
    var date = document.getElementById('DateOfBirth').value
    console.log(date, "dfate is ")
    if (date == "") {
        birth_error.innerHTML = ("please enter date");
        return false
    }

    else {
        birth_error.innerHTML = ""
        if (!date_regex.test(date)) {
            // birth_error.innerHTML = ""
            birth_error.innerHTML = "enter date on given formate "
            return false;
        }
        return true
    }
}
function phonecheck() {
    var phone_regex = /^[6-9][0-9]{9}$/;
    var phone = document.getElementById('phone').value
    if (phone == "") {
        phone_error.innerHTML = ('please enter phone number')
        return false
    }
    else {
        phone_error.innerHTML = ""
        if (!phone_regex.test(phone)) {
            // phone_error.innerHTML = ""
            phone_error.innerHTML = "phone number must be 10 digit"
            return false

        }
        return true
    }
}




function formvalidation() {

    var resf = fnamecheck();
    var resl = lnamecheck();
    var resemail = emailcheck();
    var resadd = passwordcheck();
    var resadd2 = confirmpasswordcheck();
    var resgender = gendercheck();
    var rescity = citycheck();
    var resdate = datecheck();
    var resphone = phonecheck()


try{
    if (resf == false || resl == false || resemail == false || resadd == false || resadd2 == false || resgender == false || rescity == false  || resdate == false || resphone == false ){
     { 
        return false;
    }
  
}
}
catch(error){
    console.log(error)
}


}


// function add(){
   
//     flag=formvalidation()
//     if(flag!=false){
//     console.log("add call")

//     let form=document.getElementById('form')
//     let form_data=new FormData(form)

//     const xhr=new XMLHttpRequest();
//     xhr.open("POST","/register_data",true);
//     xhr.setRequestHeader('content-type','application/x-www-form-urlencoded');

//     xhr.onload=function(){
//         if(this.status==200){
//             // const response=JSON.parse(xhr.responseText)
//             if(this.responseText=='true'){
//                 document.getElementById('email_error').innerHTML="email is exists"
//             }
//             console.log(this.responseText)
//         }
//     }
//     xhr.send(new URLSearchParams(form_data));
    
// }}



