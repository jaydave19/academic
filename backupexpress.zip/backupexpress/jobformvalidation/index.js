const express =require('express')
const app=express()
const port=8056

var bodyParser=require("body-parser"); 
app.set('view engine','ejs');

var mysql = require('mysql');
const { Result } = require('express-validator');
app.use(bodyParser.urlencoded({extended:true})); 

app.use(express.static('public'))

var connection = mysql.createConnection({
    host     : 'localhost',
    user     : 'root',
    password : 'root',
    database : 'newdesignemployee',
    dateStrings:true
});


app.get('/',(req,res)=>{
    res.render('jobform');
    
})
app.get('/practice',(req,res)=>{
    res.render('practice')
})

app.get('/get/:id',(req,res)=>{
    id=req.params.id
    console.log(id)
    connection.query(`SELECT * FROM EmployeeBasicDetails where empid='${id}'`,(err,row,fields)=>{
        if (err) throw err;
        connection.query(`SELECT * FROM EducationDetail where empid='${id}'`,(err,rowedu)=>{
            if(err)throw err;
        connection.query(`SELECT * FROM WorkExperience where empid='${id}'`,(err,rowwork)=>{
            if(err)throw err;
        
        connection.query(`SELECT * FROM LanguageMaster where empid='${id}'`,(err,row2)=>{
            if (err) throw err;
            console.log(row2,"language data =========")

        connection.query(`SELECT * FROM TechnologyMaster where empid='${id}'`,(err,row3)=>{
            if (err) throw err;
            console.log(row3,"language data =========")
        connection.query(`SELECT * FROM ReferenceContact where empid='${id}'`,(err,rowref)=>{
            if (err) throw err;
        connection.query(`SELECT * FROM preferences where empid='${id}'`,(err,rowpre)=>{
            if (err) throw err;
            res.render('jobform',{'row':row,'rowedu':rowedu,'rowwork':rowwork,'row2':row2,'row3':row3,'rowref':rowref,'rowpre':rowpre})    
        }) 
    }) 
    })

    })
    })
    })

        
    })

})
// app.get('/get/:id',(req,res)=>{
//     id=req.params.id
//     console.log(id)
//     connection.query(`SELECT * FROM EmployeeBasicDetails as emp inner join EducationDetail as edu on edu.empid=emp.empid inner join WorkExperience as w on w.empid=edu.empid where emp.empid='${id}'`,(err,row,fields)=>{
//         if (err) throw err;       
//         console.log(row,"geteed row is ") 

//         connection.query(`SELECT * FROM LanguageMaster where empid='${id}'`,(err,row)=>{
//             var rowlan;
//             if(err) throw err;
//             rowlan=row
//             console.log(rowlan)
//             res.render('jobform',{'row':row,'rowlan':rowlan})
//         })
//     })

// })

app.post('/get/:id',(req,res)=>{
    id=req.params.id
    console.log(req.body)

    connection.query(`update EmployeeBasicDetails set firstname='${req.body.fname}',lastname='${req.body.lname}',designation_eb='${req.body.designationba}',phone='${req.body.phone}',gender='${req.body.radio}',email='${req.body.email}',address1='${req.body.address1}',address2='${req.body.address2}',city='${req.body.city}',state='${req.body.state}',birthdate='${req.body.DateOfBirth}' where empid='${id}'`,(err,result)=>
    {
        if(err) throw err;
    })
  
    for(i=0;i<req.body.nob.length;i++){
        if(req.body.nob[i]!=""){
            newid=req.body.edudetailid
            console.log(newid,"newid")

            connection.query(`update EducationDetail set boardname='${req.body.nob[i]}', passingyear='${req.body.passingyear[i]}',percentage='${req.body.percentage[i]}' where edudetailid='${newid[i]}'`,(err,result)=>{
                if (err) throw err;
                console.log(result)
                if(err) throw err;
            })}
        
    }
    for(j=0;j<req.body.companyname.length;j++){
        if(req.body.companyname[j]!=""){
            newworkid=req.body.workid
            console.log(newworkid,"workid   ")
            connection.query(`update WorkExperience set compname='${req.body.companyname[j]}',designation='${req.body.designation[j]}',durationfrom='${req.body.from[j]}',durationto='${req.body.to[j]}' where workexpid='${newworkid[j]}'`,(err,result)=>{
                if(err) throw err;
            })
        }
    }
    if(req.body.language != undefined){
        for (i=0;i<req.body.language.length;i++){
            if(req.body.language[i]!=""){
                newlanid=req.body.lanid

                let read=req.body[req.body.language[i]+"_read"];
                let speak=req.body[req.body.language[i]+"_speak"];
                let write=req.body[req.body.language[i]+"_write"];
                console.log(read,"read",speak,"speak","****************************************************************")
                if(read==undefined){
                    read=0;
                }
                if(speak==undefined){
                    speak=0;
                }
                if(write==undefined){
                    write=0;
                }
            

                // req.body.language[i]
                connection.query(`update LanguageMaster set lanvalue='${req.body.language[i]}', read_test='${read}', speak='${speak}', write_test='${write}' where lanid='${newlanid[i]}'`,(err)=>{
                    if(err) throw err;
                })
            }
        }
    }

    console.log(req.body.techid[0],req.body.technology[0],"techid***************88")

    if(req.body.technology[0]){
        connection.query(`update TechnologyMaster set techvalue='${req.body.technology[0]}',techproficiency='${req.body.phpkn}' where techid='${req.body.techid[0]}'`);
    }
    if(req.body.technology[1]){
        connection.query(`update TechnologyMaster set techvalue='${req.body.technology[1]}',techproficiency='${req.body.mysqlkn}' where techid='${req.body.techid[1]}'`);
    }
    if(req.body.technology[2]){
        connection.query(`update TechnologyMaster set techvalue='${req.body.technology[2]}',techproficiency='${req.body.laravelkn}' where techid='${req.body.techid[2]}'`);
    }
    if(req.body.technology[3]){
        connection.query(`update TechnologyMaster set techvalue='${req.body.technology[3]}',techproficiency='${req.body.oraclekn}' where techid='${req.body.techid[3]}'`);
    }

    for(i=0;i<req.body.referencename.length;i++){

        if(req.body.referencename[i]!=""){
            newrefid=req.body.refid

            connection.query(`update ReferenceContact set name='${req.body.referencename[i]}',contactnumber='${req.body.contactnumber[i]}',relation='${req.body.relation[i]}' where refid='${newrefid[i]}'`,(err)=>{
                if(err) throw err;
            })
        }
    }
    connection.query(`update preferences set preferencelocation='${req.body.preferdlocation}',noticeperiod='${req.body.noticeperiod}',expectedCtc='${req.body.expectedctc}',currentCtc='${req.body.currentctc}',department='${req.body.department}' where preferenceid='${req.body.preferenceid}'`,(err)=>{
        if(err) throw err;
    })
    
    res.end('updated')

})

app.post('/',(req,res)=>{
    console.log("post")
    console.log(req.body,"body is ")

    fname=req.body.fname
    lname=req.body.lname
    dg=req.body.designationba
    phone=req.body.phone
    email=req.body.email
    address1=req.body.address1
    address2=req.body.address2
    city=req.body.city
    state=req.body.states
    birthdate=req.body.DateOfBirth
    gender=req.body.radio





   connection.query(`INSERT INTO EmployeeBasicDetails (firstname, lastname, designation_eb, phone, gender,email,address1,address2,city,state,birthdate) VALUES('${fname}','${lname}','${dg}','${phone}','${gender}','${email}','${address1}','${address2}','${city}','${state}','${birthdate}')`,(err,result)=>{
    if (err) throw err;
    lastid=result.insertId

    //insert education section details
    for(i=0;i<req.body.nob.length;i++){
        if(req.body.nob[i]!=""){

            connection.query(`INSERT INTO EducationDetail(empid,boardname,passingyear, percentage) VALUES ('${lastid}', '${req.body.nob[i]}', '${req.body.passingyear[i]}','${req.body.percentage[i]}')`,(err,result)=>{
                if (err) throw err;
            })
        }
    }
    // work experience
    for(i=0;i<req.body.companyname.length;i++){
        if(req.body.companyname[i]!=""){

            connection.query(`INSERT INTO WorkExperience(empid,compname,designation,durationfrom,durationto)VALUES ('${lastid}','${req.body.companyname[i]}','${req.body.designation[i]}','${req.body.from[i]}','${req.body.to[i]}')`,(err)=>{
                if(err) throw err;
            })
        }
    }
    //language

    if(req.body.language != undefined){
        for (i=0;i<req.body.language.length;i++){
            if(req.body.language[i]!=""){
                let read=req.body[req.body.language[i]+"_read"];
                let speak=req.body[req.body.language[i]+"_speak"];
                let write=req.body[req.body.language[i]+"_write"];
                console.log(read,"read",speak,"speak","****************************************************************")
                if(read==undefined){
                    read=0;
                }
                if(speak==undefined){
                    speak=0;
                }
                if(write==undefined){
                    write=0;
                }
            

                // req.body.language[i]
                connection.query(`INSERT INTO LanguageMaster ( lanvalue, read_test, speak, write_test, empid) VALUES ('${req.body.language[i]}','${read}','${speak}','${write}','${lastid}');`,(err)=>{
                    if(err) throw err;
                })
            }
        }
    }

    // // language 
    // var sqllan=`INSERT INTO LanguageMaster(lanvalue,languageknown, empid) VALUES (?,?,'${lastid}')`;
    // if(req.body.hindi){
    //     if(req.body.hindiread){
    //         connection.query(sqllan,[req.body.hindi,req.body.hindiread]);
    //     }
    //     if(req.body.hindiwrite){
    //         connection.query(sqllan,[req.body.hindi,req.body.hindiwrite]);
    //     }
    //     if(req.body.hindispeak){
    //         connection.query(sqllan,[req.body.hindi,req.body.hindispeak]);
    //     }
    // }
    // if(req.body.english){
    //     if(req.body.englishread){
    //         connection.query(sqllan,[req.body.english,req.body.englishread]);
    //     }
    //     if(req.body.englishwrite){
    //         connection.query(sqllan,[req.body.english,req.body.englishwrite]);
    //     }
    //     if(req.body.englishspeak){
    //         connection.query(sqllan,[req.body.english,req.body.englishspeak]);
    //     }
    // }
    // if(req.body.gujarati){
    //     if(req.body.gujaratiread){
    //         connection.query(sqllan,[req.body.gujarati,req.body.gujaratiread]);
    //     }
    //     if(req.body.gujaratiwrite){
    //         connection.query(sqllan,[req.body.gujarati,req.body.gujaratiwrite]);
    //     }
    //     if(req.body.gujaratispeak){
    //         connection.query(sqllan,[req.body.gujarati,req.body.gujaratispeak]);
    //     }
    // }
    //technology

    var sqltech=`INSERT INTO TechnologyMaster (techvalue,techproficiency,empid) VALUES (?,?, '${lastid}')`;

    if(req.body.technology[0]){
        connection.query(sqltech,[req.body.technology[0],req.body.phpkn]);
    }
    if(req.body.technology[1]){
        connection.query(sqltech,[req.body.technology[1],req.body.mysqlkn]);
    }
    if(req.body.technology[2]){
        connection.query(sqltech,[req.body.technology[2],req.body.laravelkn]);
    }
    if(req.body.technology[3]){
        connection.query(sqltech,[req.body.technology[3],req.body.oraclekn]);
    }
    

    // references

    for(i=0;i<req.body.referencename.length;i++){
        if(req.body.referencename[i]!=""){

            connection.query(`INSERT INTO ReferenceContact (name,contactnumber,relation,empid)VALUES ('${req.body.referencename[i]}','${req.body.contactnumber[i]}','${req.body.relation[i]}','${lastid}')`,(err)=>{
                if(err) throw err;
            })
        }
    }
  

    //prefere


    connection.query(`INSERT INTO preferences (preferencelocation,noticeperiod,expectedCtc,currentCtc,department,empid)VALUES ('${req.body.preferdlocation}','${req.body.noticeperiod}','${req.body.expectedctc}','${req.body.currentctc}','${req.body.department}','${lastid}')`,(err)=>{
        if(err) throw err;
    })
       
 



        

   });


   res.redirect('/')
    
})

app.get('/new',(req,res)=>{
    res.render('fetchjob');
    
})

app.listen(port,()=>{
    console.log(`listening port is ${port}`)
})