var mysql=require('mysql');
const express=require('express');
const app=express()
const port=3002

app.set('view engine','ejs');

// app.get('/',(req,res)=>{
//     res.send("hello ")
// })


var connection = mysql.createConnection({
    host     : 'localhost',
    user     : 'root',
    password : 'root',
    database : 'task26feb'
  });



app.get('/',(req,res)=>{

    connection.query('select * from studentmaster limit 100',function(error,row,fields){
        if (error) throw error;
        col=[]
        // console.log(fields[0].name,"***************")
        // console.log(row[0],"row")
        // console.log(row,"row")
        for (i=0;i<fields.length;i++){
            col.push(fields[i].name)

        }
        // console.log(col) 
        res.render('studentdetails',{'col':col,'row':row})

    })

})

app.get('/pagination/:id',(req,res)=>
{   
    var maxpage;
    maximumrow=200 
    var id=req.params.id;
    startind=(id-1)*maximumrow
    // console.log(startind,maximumrow,"*************************************************")
    connection.query('select count(*) as count from studentmaster ',function(error,row,fields){
        // console.log(row,"counter row ")
        if (error) throw error;
        maxpage=row[0].count/maximumrow;
    })
    connection.query('select * from studentmaster limit '+ startind + ',' + maximumrow,function(error,row,fields){
        if (error) throw error;
        col=[]
        for (i=0;i<fields.length;i++){
            col.push(fields[i].name)

        }
        res.render('pagination',{'id':id,'col':col,'row':row,'max':maximumrow,'startind':startind,'maxpage':maxpage})
    })
   
})


app.get('/sorting/:names/:id',(req,res)=>
{   
    var maxpage;
    maximumrow=200 
    var id=req.params.id;
    var name=req.params.names;
    console.log('name of anchor tag',name)
    startind=(id-1)*maximumrow
    // console.log(startind,maximumrow,"*************************************************")
    connection.query('select count(*) as count from studentmaster ',function(error,row,fields){
        // console.log(row,"counter row ")
        if (error) throw error;
        maxpage=row[0].count/maximumrow;
    })

    connection.query('select * from studentmaster order by '+name+' limit '+ startind + ',' + maximumrow,function(error,row,fields){
        if (error) throw error;
        col=[]
        for (i=0;i<fields.length;i++){
            col.push(fields[i].name)

        }
        res.render('sorting',{'id':id,'col':col,'row':row,'max':maximumrow,'startind':startind,'maxpage':maxpage,'name':name })
    })
    
})
// app.get('/in',(req,res)=>{
//     var id=1;
//     var date;
//     var status=["present","absent"];

//     for(i=101;i<201;i++)
//     {
//         id=i;
//         for (j=1;j<32;j++)
//         {
//             date="2024-12-"+j;
//             connection.query(`insert into attendancemaster(studentid,attendancedate,attendancestatus) values(${id},'${date}','${status[Math.floor(Math.random()*2)]}')`);
//         }
//     }
//     res.end("ok")
// })


app.get('/attendancemaster/:value/:id',(req,res)=>{
    var value=req.params.value
    var id=req.params.id
    maxrow=15;
    startind=(id-1)*maxrow
    var maxpage=Math.ceil(200/maxrow);
    console.log(maxpage,"maxpage is ")
    // var days=[31,29,31,30,31,30,31,31,30,31,30,31]
    
    for(i=0; i<days.length; i++){

    }
    connection.query(`select distinct s.studentid,s.firstname,s.lastname,count(a.studentid) as presentdays,concat(round((count(a.studentid)*100)/31,2),'%') as percentage from studentmaster as s inner join attendancemaster as a on s.studentid=a.studentid where Month(a.attendancedate)=`+value+` and a.attendancestatus='present' group by a.studentid limit `+ startind + ',' + maxrow,function(error,row,fields){
        if (error) throw error;
        // console.log(row)
        // console.log(fields)
        col=[]  
        for (i=0;i<fields.length;i++)
            col.push(fields[i].name)
        res.render('attendancemaster',{'col':col,'row':row,'id':id,'maxrow':maxrow,'maxpage':maxpage,'value':value})
    })
})



app.get('/resultmaster/:id',(req,res)=>{

    var id=req.params.id
    maxrow=15;
    startind=(id-1)*maxrow
    var maxpage=Math.ceil(200/maxrow);
    console.log(maxpage,"maxpage is ")

    connection.query(`select r.studentid,s.firstname,s.lastname,sum(case when r.examid=1 then r.totalmarkstheory end) as exam1TT,sum(case when r.examid=1 then r.obtainmarkstheory end) as exam1OT,sum(case when r.examid=1 then r.totalmarkspractical end) as exam1TP ,sum(case when r.examid=1 then r.obtainmarkspractical end) as exam1OP,
    sum(case when r.examid=2 then r.totalmarkstheory end) as exam2TT,sum(case when r.examid=2 then r.obtainmarkstheory end) as exam2OT,sum(case when r.examid=2 then r.totalmarkspractical end) as exam2TP ,sum(case when r.examid=2 then r.obtainmarkspractical end) as exam2OP,
    sum(case when r.examid=3 then r.totalmarkstheory end) as exam3TT,sum(case when r.examid=3 then r.obtainmarkstheory end) as exam3OT,sum(case when r.examid=3 then r.totalmarkspractical end) as exam3TP ,sum(case when r.examid=3 then r.obtainmarkspractical end) as exam3OP,((sum(case when r.examid=1 then r.obtainmarkstheory end)+sum(case when r.examid=1 then r.obtainmarkspractical end))+(sum(case when r.examid=2 then r.obtainmarkstheory end)+sum(case when r.examid=2 then r.obtainmarkspractical end))+(sum(case when r.examid=3 then r.obtainmarkstheory end)+sum(case when r.examid=3 then r.obtainmarkspractical end))) as finalmarks
    from resultmaster as r inner join studentmaster as s on r.studentid=s.studentid where subjectid between 1 and 6 group by studentid limit `+ startind + ',' + maxrow,function(error,row,fields){
        if (error) throw error;
        // console.log(row)
        // console.log(fields)
        col=[]  
        for (i=0;i<fields.length;i++)
            col.push(fields[i].name)
        res.render('resultmaster',{'col':col,'row':row,'id':id,'maxrow':maxrow,'maxpage':maxpage})

    })
})



app.get('/specificresult/:id',(req,res)=>{
    var id= req.params.id
    console.log(id)
    
    connection.query(`select s.studentid,s.firstname,s.lastname,sub.subjectname,r.subjectid,r.examid,r.obtainmarkstheory,r.obtainmarkspractical,(r.obtainmarkstheory+r.obtainmarkspractical) as total from studentmaster as s inner join resultmaster as r on s.studentid = r.studentid inner join subjectmaster as sub on sub.subject_id=r.subjectid where r.studentid=`+id,function(error,row,fields){
        col=[]
        marks1=[]
        marks2=[]
        marks3=[]
        for (i=0;i<fields.length;i++)
            col.push(fields[i].name)

        for (i=0;i<row.length;i++){
            if (row[i].examid==1){
                marks1.push(row[i].total)
            }
            if (row[i].examid==2){
                marks2.push(row[i].total)
            }
            if (row[i].examid==3){
                marks3.push(row[i].total)
            }
            
        }
        let sum1 = 0;
        marks1.forEach((el) => sum1 += el);
        percentage1=(sum1*100/300).toFixed(2)+' '+`%`
        console.log(percentage1,'1')
        
        let sum2=0;
        marks2.forEach((el) => sum2 += el);
        percentage2=(sum2*100/300).toFixed(2)+' '+`%`
        console.log(percentage2,"2")

        let sum3=0;
        marks3.forEach((el) => sum3 += el);
        percentage3=(sum3*100/600).toFixed(2)+' '+`%`
        console.log(percentage3,"3")

    res.render('specificresult',{'col':col,'row':row,'percentage1':percentage1,'percentage2':percentage2,'percentage3':percentage3}) })
})

app.listen(port,()=>{
    console.log(`listening port is ${port}`)
})


